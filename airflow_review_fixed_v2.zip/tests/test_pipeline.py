import csv
import json
from pathlib import Path
import sys
from unittest.mock import patch
import uuid
import zipfile
import pytest
import pyarrow as pa
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from commands_functions import pipeline as p, storage, sources, control, sms_functions as sms
from test_batch import Cursor

TREE = str(uuid.UUID(int=16))
UID = str(uuid.UUID(int=1))

@pytest.fixture
def command(tmp_path):
    return dict(tree_guid=TREE, owner='a'*64, kom_prefix='prefix', root=str(tmp_path/'remote'))


def setup_plan(tmp_path, command, n=1):
    selected = [dict(IDENTIFICATOR=f'{i:03}',TYPE=2,IDENT_UUID=str(uuid.UUID(int=i+1))) for i in range(n)]
    main = [dict(IDENTIFICATOR=r['IDENTIFICATOR'],TYPE=r['TYPE']) for r in selected]
    snapshot = storage.put_json(str(tmp_path/'snap.json'), dict(command=command,main=main,clean=main,blocked=[]))
    batch = dict(command=command,db_config=dict(tree_guid=TREE,type=2,server='s',database='d'),
                 ident_batch=[dict(ident=r['IDENTIFICATOR'],type=2,uuid=r['IDENT_UUID']) for r in selected],batch_id='batch')
    br = storage.put_json(str(tmp_path/'batch.json'),batch)
    plan = dict(command=command,snapshot=snapshot,selected=selected,batches=[br],stats={'planned_batches':1})
    return batch, br, storage.put_json(str(tmp_path/'plan.json'),plan)


def row(ident='000',uid=UID):
    return {**{c: '' for c in sms.SMS_COLUMNS}, 'TEXT':'001\tстрока\nвторая',
            'TREE_GUID':TREE,'IDENT_UUID':uid,'IDENT_TYPE':'2','MATCHED_IDENTIFICATOR':ident}


def extracted(tmp_path,command,br,batch,rows):
    chunks = []
    if rows:
        local=tmp_path/'rows.parquet'
        pq.write_table(pa.Table.from_pylist(rows),local)
        chunks=[{**storage.upload(local,str(tmp_path/'remote/chunk.parquet')),'rows':len(rows)}]
    return storage.put_json(str(tmp_path/'out.json'),dict(batch_ref=br,batch_id=batch['batch_id'],
             command=command,chunks=chunks,rows=len(rows),seconds=1.0,source='source'))


def test_real_parquet_csv_zip_and_publish_retry(tmp_path,command):
    batch,br,pr=setup_plan(tmp_path,command)
    out=extracted(tmp_path,command,br,batch,[row(),row()])
    state={'owner':command['owner'],'state':'RUNNING'}
    def complete(tree, owner, manifest, sha):
        state.update(state='SUCCEEDED',manifest=manifest,sha256=sha)
    with patch.object(control,'current',side_effect=lambda _: dict(state)), patch.object(control,'complete',side_effect=complete):
        ref=p.publish(pr,[out])
        assert p.publish(pr,[]) == ref  # committed publication retry, no new files
    manifest=storage.get_json(ref)
    assert manifest['stats']['sms_rows']==2
    with zipfile.ZipFile(manifest['archive']['path']) as z:
        assert len(z.namelist())==2
        sms_name=next(n for n in z.namelist() if n.endswith('.SMS'))
        import io
        rows=list(csv.DictReader(io.StringIO(z.read(sms_name).decode()),delimiter='\t'))
        assert len(rows)==2 and rows[0]['TEXT']=='001\tстрока\nвторая'
        receipt=list(csv.DictReader(io.StringIO(z.read('prefix.KVT').decode()),delimiter='\t'))
        assert next(r for r in receipt if r['RRR']=='SMS')['Count']=='2'
        assert receipt[0]['ID']=='000'


def test_empty_mapping_creates_zero_receipt(tmp_path,command):
    _,_,pr=setup_plan(tmp_path,command)
    data=storage.get_json(pr);data['batches']=[];data['selected']=[];data['stats']['planned_batches']=0
    pr=storage.put_json(str(tmp_path/'empty_plan.json'),data)
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete') as done:
        ref=p.publish(pr,[])
    assert done.call_count==1
    assert storage.get_json(ref)['stats']['sms_rows']==0


@pytest.mark.parametrize('kind',['missing','duplicate','none','foreign','count'])
def test_incomplete_results_block_publication(tmp_path,command,kind):
    b,br,pr=setup_plan(tmp_path,command)
    out=extracted(tmp_path,command,br,b,[])
    refs={'missing':[],'duplicate':[out,out],'none':[None]}.get(kind,[out])
    if kind in ('foreign','count'):
        data=storage.get_json(out)
        if kind=='foreign':data['batch_ref']={**br,'sha256':'other'}
        else:data['rows']=1
        refs=[storage.put_json(str(tmp_path/'bad.json'),data)]
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete') as done:
        with pytest.raises(ValueError):p.publish(pr,refs)
        done.assert_not_called()


def test_corrupt_chunk_blocks_commit(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command);out=extracted(tmp_path,command,br,b,[row()])
    Path(storage.get_json(out)['chunks'][0]['path']).write_bytes(b'bad')
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete') as done:
        with pytest.raises(ValueError):p.publish(pr,[out])
        done.assert_not_called()


def test_foreign_row_blocks_commit(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command);out=extracted(tmp_path,command,br,b,[row(uid=str(uuid.UUID(int=99)))])
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete') as done:
        with pytest.raises(ValueError):p.publish(pr,[out])
        done.assert_not_called()


def test_failed_upload_never_completes(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command);out=extracted(tmp_path,command,br,b,[])
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete') as done,patch.object(storage,'upload',side_effect=OSError('offline')):
        with pytest.raises(OSError):p.publish(pr,[out])
        done.assert_not_called()


def test_extraction_uses_sink_and_bounded_chunks(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command)
    def fetch(db, batch, on_chunk, fetch_size):
        for _ in range(3):on_chunk([row()])
        return 3
    with patch.object(control,'assert_owner'),patch.object(p,'get_fuzzy_sms_data',side_effect=fetch):
        a=p.extract(br); b=p.extract(br)
    data=storage.get_json(a)
    assert data['rows']==3 and len(data['chunks'])==3
    assert a['path']!=b['path']
    for c in data['chunks']:
        table=pq.read_table(c['path']); assert table.column('MATCHED_IDENTIFICATOR')[0].as_py()=='000'


def test_stream_reader_does_not_return_accumulated_rows():
    rows=[row() for _ in range(5)]
    cols=list(rows[0])
    cursor=Cursor([(cols,[[r[c] for c in cols] for r in rows])])
    chunks=[]
    count=sms.read_sms_batch_result(cursor,[dict(ident='000',type=2,uuid=UID)],TREE,
                                     on_chunk=lambda rows: chunks.append(len(rows)),fetch_size=2)
    assert count==5 and chunks==[2,2,1]


def test_sink_error_propagates():
    cols=list(row());cur=Cursor([(cols,[[row()[c] for c in cols]])])
    def fail(rows):raise OSError('disk full')
    with pytest.raises(OSError):sms.read_sms_batch_result(cur,[dict(ident='000',type=2,uuid=UID)],TREE,on_chunk=fail)


def test_final_blacklist_on_both_link_endpoints(tmp_path,command):
    records=[dict(Idn1='blocked',t1=19,Idn2='ok',t2=2),
             dict(Idn1='allowed-imei',t1=20,Idn2='foreign-imei',t2=20)]
    local=tmp_path/'links.jsonl';local.write_text(''.join(json.dumps(r)+'\n' for r in records))
    ref=storage.upload(local,str(tmp_path/'remote/links.jsonl'))
    snap=dict(command=command,clean=[dict(IDENTIFICATOR='allowed-imei',TYPE=20)],blocked=['blocked'])
    selected,stats=p.select_inputs(dict(files=[ref]),snap)
    assert {(r['IDENTIFICATOR'],r['TYPE']) for r in selected}=={('ok',2),('allowed-imei',20)}
    assert stats['blocked_final']==1 and stats['excluded_imei']==1


def test_clickhouse_batches_unique_pairs_and_keeps_values():
    class Client:
        def __init__(self):self.calls=[]
        def execute_iter(self,sql,external_tables,settings):
            self.calls.append(external_tables[0]['data']);return iter([])
    c=Client();assert list(sources.iter_links(c,[('001',2),('001',19),('001',2),('002',2)],2))==[]
    assert [len(b) for b in c.calls]==[2,1]
    assert set(sum(c.calls,[]))=={('001',2),('001',19),('002',2)}


def test_two_link_passes_use_target_keys_and_persist(tmp_path,command):
    snap=dict(command=command,main=[],clean=[dict(IDENTIFICATOR='a',TYPE=2)],blocked=['blocked'])
    ref=storage.put_json(str(tmp_path/'snapshot.json'),snap); calls=[]
    class Client:
        closed=False
        def disconnect_connection(self):self.closed=True
    client=Client()
    def it(client,keys,size):
        calls.append(set(keys))
        if len(calls)==1:
            return iter([dict(Idn1='a',t1=2,Idn2=x,t2=t) for x,t in [('b',19),('blocked',2),('imei',20)]])
        return iter([dict(Idn1='b',t1=19,Idn2='c',t2=2)])
    with patch.object(control,'assert_owner'),patch.object(sources,'clickhouse_client',return_value=client),patch.object(sources,'iter_links',side_effect=it):
        result=p.links(ref)
    assert calls==[{('a',2)},{('b',19)}] and client.closed
    assert storage.get_json(result)['counts']==[3,1]


def test_routing_dedups_then_chunks_and_separates_instances(command):
    selected=[dict(IDENTIFICATOR=f'{i:03}',TYPE=2,IDENT_UUID=str(uuid.UUID(int=i+1))) for i in range(51)]
    locs=[dict(SERVER='s',INSTANCE=i,DATABASE='d',IDENTIFICATOR_TYPE=2) for i in ['a','b']]
    batches=p.route_batches(selected+selected,locs+locs,command,50)
    assert [len(b['ident_batch']) for b in batches]==[50,1,50,1]
    assert len({b['batch_id'] for b in batches})==4
    assert batches==p.route_batches(selected,locs,command,50)


def test_missing_catalog_does_not_silently_drop_type(command):
    with pytest.raises(ValueError):p.route_batches([dict(IDENTIFICATOR='001',TYPE=19,IDENT_UUID=UID)],[],command,50)


def test_json_checksum_detects_mutation(tmp_path):
    ref=storage.put_json(str(tmp_path/'a.json'),dict(x=1));Path(ref['path']).write_text('{}')
    with pytest.raises(ValueError):storage.get_json(ref)


def test_ownership_loss_blocks_extract(tmp_path,command):
    _,br,_=setup_plan(tmp_path,command)
    with patch.object(control,'current',return_value={'owner':'other','state':'RUNNING'}),patch.object(p,'get_fuzzy_sms_data') as fetch:
        with pytest.raises(RuntimeError):p.extract(br)
        fetch.assert_not_called()


def test_control_transaction_commits_and_rolls_back():
    import types
    from unittest.mock import Mock
    raw=Mock();hook=Mock();hook.get_conn.return_value=raw
    module=types.ModuleType('airflow.providers.microsoft.mssql.hooks.mssql');module.MsSqlHook=Mock(return_value=hook)
    with patch.dict(sys.modules,{'airflow.providers.microsoft.mssql.hooks.mssql':module}):
        with control.connection():pass
        raw.commit.assert_called_once();raw.close.assert_called_once()
        with pytest.raises(ValueError):
            with control.connection():raise ValueError('failure')
        raw.rollback.assert_called_once();assert raw.close.call_count==2


def test_claim_retry_resumes_same_tree_without_source_query(command):
    import types
    module=types.ModuleType('airflow.exceptions');module.AirflowSkipException=type('AirflowSkipException',(Exception,),{})
    with patch.dict(sys.modules,{'airflow.exceptions':module}),patch.object(control,'for_run',return_value=dict(tree=TREE,prefix='prefix',state='RUNNING')),patch.object(sources,'candidates') as source:
        result=p.claim('dag','run')
    source.assert_not_called();assert result['tree_guid']==TREE


def test_multiple_sources_merge_same_identifier(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command)
    first=extracted(tmp_path,command,br,b,[row()])
    b2={**b,'batch_id':'second','db_config':{**b['db_config'],'server':'other'}}
    br2=storage.put_json(str(tmp_path/'second_batch.json'),b2)
    second_dir=tmp_path/'second';second_dir.mkdir()
    second=extracted(second_dir,command,br2,b2,[row(),row()])
    data=storage.get_json(pr);data['batches'].append(br2);data['stats']['planned_batches']=2
    pr=storage.put_json(str(tmp_path/'two_plan.json'),data)
    with patch.object(control,'current',return_value={'owner':command['owner'],'state':'RUNNING'}),patch.object(control,'complete'):
        ref=p.publish(pr,[second,first])
    result=storage.get_json(ref)
    assert result['stats']['sms_rows']==3 and result['stats']['completed_batches']==2
    assert len([f for f in result['files'] if f['path'].endswith('.SMS')])==1


def test_commit_response_lost_reuses_published_manifest(tmp_path,command):
    b,br,pr=setup_plan(tmp_path,command);out=extracted(tmp_path,command,br,b,[])
    state={'owner':command['owner'],'state':'RUNNING'}
    def lost_response(tree,owner,manifest,sha):
        state.update(state='SUCCEEDED',manifest=manifest,sha256=sha)
        raise ConnectionError('response lost after commit')
    with patch.object(control,'current',side_effect=lambda _:dict(state)),patch.object(control,'complete',side_effect=lost_response) as done:
        with pytest.raises(ConnectionError):p.publish(pr,[out])
        ref=p.publish(pr,[out])
        assert ref['path']==state['manifest'] and done.call_count==1


def test_plan_applies_selection_before_catalog_mapping(tmp_path,command):
    clean=[dict(IDENTIFICATOR='imei',TYPE=20)]
    snap=storage.put_json(str(tmp_path/'snap.json'),dict(command=command,main=clean,clean=clean,blocked=['blocked']))
    local=tmp_path/'links.jsonl'
    local.write_text(json.dumps(dict(Idn1='imei',t1=20,Idn2='blocked',t2=19))+'\n'+json.dumps(dict(Idn1='phone',t1=2,Idn2='foreign',t2=20))+'\n')
    links=storage.upload(local,str(tmp_path/'remote/links.jsonl'))
    lr=storage.put_json(str(tmp_path/'links_manifest.json'),dict(snapshot=snap,files=[links],counts=[2,0],queries=1))
    loc=[dict(SERVER='s',INSTANCE=None,DATABASE='d',IDENTIFICATOR_TYPE=t) for t in (2,20)]
    with patch.object(control,'assert_owner'),patch.object(sources,'catalog',return_value=loc):
        pr=p.plan(lr)
    data=storage.get_json(pr)
    assert {(r['TYPE'],r['IDENTIFICATOR']) for r in data['selected']}=={(2,'phone'),(20,'imei')}
    assert len(p.batch_refs(pr))==2
    assert set(pr)=={'path','bytes','sha256'}


def test_no_candidate_is_skip_and_does_not_reserve():
    import types
    module=types.ModuleType('airflow.exceptions');module.AirflowSkipException=type('AirflowSkipException',(Exception,),{})
    with patch.dict(sys.modules,{'airflow.exceptions':module}),patch.object(control,'for_run',return_value=None),patch.object(sources,'candidates',return_value=[]),patch.object(control,'reserve') as reserve:
        with pytest.raises(module.AirflowSkipException):p.claim('dag','empty_run')
        reserve.assert_not_called()


def test_none_outputs_are_valid_only_for_empty_plan():
    assert p.validate_outputs([],None)==[]
    with pytest.raises(ValueError):p.validate_outputs([dict(sha256='a')],None)
