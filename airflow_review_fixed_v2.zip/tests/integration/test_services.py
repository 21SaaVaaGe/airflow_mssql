"""Opt-in tests. SQL tests create/drop one uniquely named database on a TEST server."""
import os
from pathlib import Path
import re
import sys
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from commands_functions import sources, sms_functions as sms

ROOT=Path(__file__).resolve().parents[2]


def run_script(cursor,path):
    for batch in re.split(r'^GO\s*$',path.read_text(),flags=re.MULTILINE|re.IGNORECASE):
        if batch.strip():cursor.execute(batch)


@pytest.fixture(scope='module')
def sql_database():
    if os.environ.get('RUN_MSSQL_INTEGRATION')!='1':pytest.skip('RUN_MSSQL_INTEGRATION=1 required')
    import pymssql
    params=dict(server=os.environ['TEST_MSSQL_HOST'],port=int(os.environ.get('TEST_MSSQL_PORT','1433')),
                user=os.environ.get('TEST_MSSQL_USER','sa'),password=os.environ['TEST_MSSQL_PASSWORD'],autocommit=True)
    name='airflow_pipeline_test_'+uuid.uuid4().hex
    admin=pymssql.connect(**params)
    try:
        admin.cursor().execute(f'CREATE DATABASE [{name}]')
        def connect():return pymssql.connect(**params,database=name)
        conn=connect()
        try:
            cur=conn.cursor();cur.execute('CREATE SCHEMA IAR');cur.execute('CREATE SCHEMA STATISTICS')
            # Source columns explicitly enumerated from the supplied procedure's contract.
            cols='''Korr PID LID DATE_TIME OPC DPC NETWORK_INDICATOR CALLED_PARTY_ADDRESS
            NAI_CALLED_PARTY_ADDRESS NP_CALLED_PARTY_ADDRESS SSN_CALLED_PARTY_ADDRESS
            CALLING_PARTY_ADDRESS NAI_CALLING_PARTY_ADDRESS NP_CALLING_PARTY_ADDRESS
            SSN_CALLING_PARTY_ADDRESS SERVICE_CENTRE TN_SERVICE_CENTRE NP_SERVICE_CENTRE
            PHONE_IDENTIFICATOR_FROM TN_PHONE_IDENTIFICATOR_FROM PN_PHONE_IDENTIFICATOR_FROM
            IMSI_IDENTIFICATOR_FROM IMEI_IDENTIFICATOR_FROM PHONE_IDENTIFICATOR_TO
            TN_PHONE_IDENTIFICATOR_TO PN_PHONE_IDENTIFICATOR_TO IMSI_IDENTIFICATOR_TO IMEI_IDENTIFICATOR_TO MSG'''.split()
            cur.execute('CREATE TABLE STATISTICS.ARCHIVE_SMS_FTI ('+','.join(f'[{c}] NVARCHAR(255) NULL' for c in cols)+')')
            cur.execute("INSERT STATISTICS.ARCHIVE_SMS_FTI(PHONE_IDENTIFICATOR_FROM,IMSI_IDENTIFICATOR_TO,IMEI_IDENTIFICATOR_FROM,MSG) VALUES(N'001',N'001',N'003',N'hello')")
            run_script(cur,ROOT/'sql/GET_STAT_SMS_BATCH.sql');run_script(cur,ROOT/'sql/COMMAND_EXECUTION.sql')
        finally:conn.close()
        yield connect
    finally:
        admin.cursor().execute(f'ALTER DATABASE [{name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE')
        admin.cursor().execute(f'DROP DATABASE [{name}]');admin.close()


def test_real_sql_six_joins_and_session_isolation(sql_database):
    a,b=sql_database(),sql_database()
    tree=str(uuid.uuid4())
    batch=[dict(ident=v,type=t,uuid=str(uuid.uuid4())) for v,t in [('001',2),('001',19),('003',20),('missing',2)]]
    try:
        c=a.cursor();c.execute('CREATE TABLE #idents(IDENTIFICATOR NVARCHAR(255) NOT NULL,IDENT_TYPE INT NOT NULL,IDENT_UUID UNIQUEIDENTIFIER NOT NULL,PRIMARY KEY(IDENT_TYPE,IDENTIFICATOR))')
        c.executemany('INSERT #idents VALUES(%s,%s,%s)',[(r['ident'],r['type'],r['uuid']) for r in batch])
        c.execute('EXEC IAR.GET_STAT_SMS_BATCH @TREE_GUID=%s',(tree,))
        rows=sms.read_sms_batch_result(c,batch,tree)
        assert len(rows)==3 and {int(r['IDENT_TYPE']) for r in rows}=={2,19,20}
        with pytest.raises(Exception):b.cursor().execute('SELECT * FROM #idents')
        c.execute('DROP TABLE #idents')
    finally:a.close();b.close()


def test_real_control_competing_reservation_and_fencing(sql_database):
    tree=str(uuid.uuid4()); owners=[uuid.uuid4().hex*2 for _ in range(2)]; barrier=threading.Barrier(2)
    def reserve(owner):
        conn=sql_database()
        try:
            barrier.wait();c=conn.cursor()
            c.execute('EXEC AIRFLOW_CONTROL.RESERVE %s,%s,%s',(tree,owner,'prefix'))
            return owner,bool(c.fetchone()[0])
        finally:conn.close()
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(reserve,owners))
    assert sum(ok for _,ok in results)==1
    winner=next(owner for owner,ok in results if ok);loser=next(owner for owner,ok in results if not ok)
    conn=sql_database();c=conn.cursor()
    try:
        with pytest.raises(Exception):c.execute('EXEC AIRFLOW_CONTROL.COMPLETE %s,%s,%s,%s',(tree,loser,'url','a'*64))
        c.execute('EXEC AIRFLOW_CONTROL.COMPLETE %s,%s,%s,%s',(tree,winner,'url','a'*64))
        c.execute('EXEC AIRFLOW_CONTROL.COMPLETE %s,%s,%s,%s',(tree,winner,'url','a'*64))
        c.execute('EXEC AIRFLOW_CONTROL.FAIL_RUN %s,%s',(winner,'late-failure'))
        c.execute('SELECT STATE FROM AIRFLOW_CONTROL.Execution WHERE TREE_GUID=%s',(tree,))
        assert c.fetchone()[0]=='SUCCEEDED'
    finally:conn.close()


def test_real_clickhouse_external_table_join():
    if os.environ.get('RUN_CLICKHOUSE_INTEGRATION')!='1':pytest.skip('RUN_CLICKHOUSE_INTEGRATION=1 required')
    from clickhouse_driver import Client
    c=Client(host=os.environ['TEST_CLICKHOUSE_HOST'],port=int(os.environ.get('TEST_CLICKHOUSE_PORT','9000')),
             user=os.environ.get('TEST_CLICKHOUSE_USER','default'),password=os.environ.get('TEST_CLICKHOUSE_PASSWORD',''))
    try:
        # Session temporary table, no production schemas touched.
        c.execute('CREATE TEMPORARY TABLE link_fixture (Idn1 String,t1 Int32,Idn2 String,t2 Int32)')
        c.execute('INSERT INTO link_fixture VALUES',[('001',2,'002',19),('001',19,'003',2)])
        rows=c.execute_iter('SELECT e.* FROM link_fixture e INNER JOIN input_idents i ON e.Idn1=i.ident AND e.t1=i.typ',
            external_tables=[dict(name='input_idents',structure=[('ident','String'),('typ','Int32')],data=[('001',2)])])
        assert list(rows)==[('001',2,'002',19)]
    finally:c.disconnect_connection()


def test_real_s3_upload_read_and_checksum(tmp_path):
    if os.environ.get('RUN_S3_INTEGRATION')!='1':pytest.skip('RUN_S3_INTEGRATION=1 required')
    from unittest.mock import patch
    from commands_functions import storage
    base=os.environ['TEST_S3_PREFIX'].rstrip('/')+'/'+uuid.uuid4().hex
    options={'key':os.environ['TEST_S3_KEY'],'secret':os.environ['TEST_S3_SECRET'],
             'client_kwargs':{'endpoint_url':os.environ['TEST_S3_ENDPOINT']}}
    with patch.object(storage,'get_storage_options',return_value=options):
        try:
            ref=storage.put_json(base+'/test.json',{'text':'001'});assert storage.get_json(ref)=={'text':'001'}
            storage.verify(ref)
        finally:
            fs,key=storage.fs_for(base);fs.rm(key,recursive=True)
