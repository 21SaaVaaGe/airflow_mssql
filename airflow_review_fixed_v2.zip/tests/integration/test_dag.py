import os
from pathlib import Path
import sys
import pytest


def test_actual_dagbag_import_and_empty_mapping_contract():
    if os.environ.get('RUN_AIRFLOW_INTEGRATION')!='1':pytest.skip('RUN_AIRFLOW_INTEGRATION=1 required')
    from airflow.models.dagbag import DagBag
    root=Path(__file__).resolve().parents[2]
    sys.path.insert(0,str(root))
    bag=DagBag(dag_folder=str(root/'test.py'),include_examples=False)
    assert not bag.import_errors,bag.import_errors
    dag=bag.dags['identity_enrichment_report']
    assert len(dag.tasks)==7
    assert dag.get_task('publish_result').trigger_rule=='none_failed_min_one_success'
    assert dag.get_task('extract_batch').pool==os.environ.get('COMMANDS_SMS_POOL','commands_sms')
    assert dag.get_task('publish_result').upstream_task_ids=={'plan_batches','extract_batch'}
