"""Business rules for procedure inputs, before catalog routing and batching."""
import unittest
from test_regressions import load_functions

TREE = '00000000-0000-0000-0000-000000000010'

class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.n = load_functions()

    def select(self, links, main=()):
        return self.n['select_procedure_identifiers'](links, main)

    def test_unique_endpoints_across_passes_and_directions(self):
        rows = [dict(Idn1=' 001 ', t1='2', Idn2='001', t2=19),
                dict(Idn1='001', t1=19, Idn2='001', t2=2)]
        self.assertEqual(self.select(rows * 3), [dict(IDENTIFICATOR='001', TYPE=2),
                                               dict(IDENTIFICATOR='001', TYPE=19)])

    def test_imei_requires_same_value_and_type_in_main(self):
        rows = [dict(Idn1='001', t1=20, Idn2='002', t2=20)]
        main = [dict(IDENTIFICATOR=' 001 ', TYPE='20'), dict(IDENTIFICATOR='002', TYPE=2)]
        self.assertEqual(self.select(rows, main), [dict(IDENTIFICATOR='001', TYPE=20)])
        self.assertEqual(self.select(rows), [])

    def test_bare_main_rows_do_not_count_as_links(self):
        main = [dict(IDENTIFICATOR='001', TYPE=t) for t in (2, 19, 20)]
        self.assertEqual(self.select(main, main), [])
        self.assertEqual(self.select([], main), [])

    def test_other_types_and_empty_values_excluded(self):
        rows = [dict(Idn1='mail', t1=9, Idn2=None, t2=19),
                dict(Idn1=' ', t1=2, Idn2='003', t2=19)]
        self.assertEqual(self.select(rows), [dict(IDENTIFICATOR='003', TYPE=19)])

    def test_selection_is_stable_and_does_not_mutate_input(self):
        rows = [dict(Idn1='001', t1=19, Idn2='002', t2=2)]
        original = [dict(row) for row in rows]
        a = self.select(rows)
        b = self.select(rows * 2)
        self.assertEqual(a, b)
        self.assertEqual(rows, original)

if __name__ == '__main__':
    unittest.main()
