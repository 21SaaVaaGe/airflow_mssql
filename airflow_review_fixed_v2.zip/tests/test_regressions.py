"""Shared loader uses real imported SMS functions with isolated globals for DB doubles."""
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from commands_functions import sms_functions


def load_functions():
    ns = dict(vars(sms_functions))
    for name, func in list(ns.items()):
        if isinstance(func, types.FunctionType) and func.__module__ == sms_functions.__name__:
            ns[name] = types.FunctionType(func.__code__, ns, name, func.__defaults__, func.__closure__)
    return ns
