# Результат проверок

Дата: 2026-09-22.

## Чистая среда с Airflow

Команда: `RUN_AIRFLOW_INTEGRATION=1 python -m pytest tests -q`.

**44 passed, 4 skipped, 4 subtests passed**. Время тестов: 4,75 с.

Проверены реальные импорты DAG через DagBag, семь задач, зависимости, пул и trigger rule публикации. Локальные тесты используют настоящие Parquet/CSV/ZIP и файловые операции. Тела функций не извлекаются через AST.

Пропущены: два теста SQL Server (процедура и конкурентное резервирование), один ClickHouse и один S3. Они требуют подключений к тестовым сервисам. Полное выполнение scheduler/executor и реальных источников не проводилось.

## Проверка без Airflow

`python -m pytest tests -q`: **43 passed, 5 skipped, 4 subtests passed**.

Дополнительно выполнена компиляция Python.

## Версии чистой среды

Python 3.12.14.

| Пакет | Версия |
|---|---|
| apache-airflow | 3.1.0 |
| apache-airflow-providers-microsoft-mssql | 4.3.2 |
| pandas | 2.1.4 |
| pyarrow | 18.1.0 |
| fsspec | 2025.9.0 |
| s3fs | 2025.9.0 |
| SQLAlchemy | 1.4.54 |
| pymssql | 2.3.7 |
| clickhouse-driver | 0.2.11 |
| pytest | 9.1.1 |

Полный снимок зависимостей — requirements-tested.txt. Среда собрана с официальным constraints-файлом Airflow 3.1.0 для Python 3.12; это отдельная тестовая среда, не изменение вашего Airflow.
