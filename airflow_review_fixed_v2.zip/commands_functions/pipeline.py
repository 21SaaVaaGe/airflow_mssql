"""Task bodies independent of Airflow decorators. Large rows live in object storage."""
import csv
import hashlib
import json
import logging
import os
from pathlib import Path
import tempfile
import time
import uuid
import zipfile
from collections import Counter, defaultdict
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from . import control, sources, storage
from .sms_functions import (SMS_COLUMNS, S3_BASE_BUCKET, safe_component, ident_name,
                            normalize_ident_batch, get_fuzzy_sms_data, select_procedure_identifiers)

logger = logging.getLogger(__name__)


def positive_env(name, default):
    value = int(os.environ.get(name, str(default)))
    if value < 1:
        raise ValueError(f'{name} must be positive')
    return value


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def metrics(event, **counts):
    # Only counters, elapsed times and opaque run keys; no searched values.
    logger.info('pipeline_metrics %s', json.dumps({'event': event, **counts}, sort_keys=True))


def claim(dag_id, run_id):
    from airflow.exceptions import AirflowSkipException
    owner = control.run_key(dag_id, run_id)
    def context(tree, prefix):
        return dict(tree_guid=tree, owner=owner, kom_prefix=prefix,
                    root=f'{S3_BASE_BUCKET}/{tree}/runs/{owner}')
    existing = control.for_run(owner)
    if existing:
        if existing['state'] == 'RUNNING':
            return context(str(uuid.UUID(existing['tree'])), existing['prefix'])
        raise AirflowSkipException('Run already terminal; use administrative reset and a new run')
    for row in sources.candidates():
        tree = str(uuid.UUID(str(row['TREE_GUID'])))
        prefix = safe_component(f"{row['TREE_NAME']}_{pd.Timestamp(row['DATE_INPUT']).strftime('%Y%m%d')}_14")
        if control.reserve(tree, owner, prefix):
            return context(tree, prefix)
    raise AirflowSkipException('No unreserved commands')


def snapshot(command):
    control.assert_owner(command['tree_guid'], command['owner'])
    main, blocked = sources.main_identifiers(command['tree_guid']), sources.blacklist()
    for row in main:
        ident_name(row['TYPE'])  # validate receipt types before expensive extraction
    clean = [r for r in main if r['IDENTIFICATOR'] not in blocked]
    data = dict(command=command, main=main, clean=clean, blocked=sorted(blocked))
    # Attempt-specific path: previous task outputs remain immutable on clear/retry.
    ref = storage.put_json(f"{command['root']}/snapshots/{uuid.uuid4().hex}.json", data)
    metrics('snapshot', main=len(main), clean=len(clean), blocked_main=len(main)-len(clean))
    return ref


def links(snapshot_ref):
    snap = storage.get_json(snapshot_ref)
    command = snap['command']
    control.assert_owner(command['tree_guid'], command['owner'])
    blocked = set(snap['blocked'])
    first_keys = {(r['IDENTIFICATOR'], int(r['TYPE'])) for r in snap['clean']}
    size = positive_env('COMMANDS_LINK_BATCH_SIZE', 500)
    second_keys, refs, counts = set(), [], []
    client = sources.clickhouse_client() if first_keys else None
    attempt = uuid.uuid4().hex
    try:
        with tempfile.TemporaryDirectory() as tmp:
            for level in (1, 2):
                keys = first_keys if level == 1 else second_keys
                count = 0
                local = Path(tmp) / f'links_{level}.jsonl'
                with local.open('w', encoding='utf-8') as f:
                    for row in sources.iter_links(client, keys, size) if keys else ():
                        f.write(json.dumps(row, ensure_ascii=False) + '\n')
                        count += 1
                        if level == 1 and row['t2'] in (2, 19) and row['Idn2'] not in blocked:
                            second_keys.add((row['Idn2'], row['t2']))
                refs.append(storage.upload(local, f"{command['root']}/links/{attempt}/{level}.jsonl"))
                counts.append(count)
    finally:
        if client is not None:
            client.disconnect_connection()
    result = dict(snapshot=snapshot_ref, files=refs, counts=counts,
                  queries=sum((len(k)+size-1)//size for k in (first_keys, second_keys)))
    metrics('links', first=counts[0], second=counts[1], queries=result['queries'])
    return storage.put_json(f"{command['root']}/links/{attempt}/manifest.json", result)


def select_inputs(link_manifest, snap):
    selected, excluded_imei = {}, set()
    blocked, clean = set(snap['blocked']), snap['clean']
    main_imei = {r['IDENTIFICATOR'] for r in clean if int(r['TYPE']) == 20}
    # select_procedure_identifiers is shared with external callers.
    # Process bounded chunks, not all link rows at once.
    block = []
    def consume(rows):
        for row in rows:
            for vc, tc in (('Idn1','t1'),('Idn2','t2')):
                if row[tc] == 20 and row[vc] not in main_imei:
                    excluded_imei.add(row[vc])
        for row in select_procedure_identifiers(rows, clean):
            selected[(row['IDENTIFICATOR'], row['TYPE'])] = row
    for ref in link_manifest['files']:
        storage.verify(ref)
        with storage.open_file(ref['path']) as f:
            for line in f:
                block.append(json.loads(line))
                if len(block) >= 1000:
                    consume(block)
                    block.clear()
        if block:
            consume(block)
            block.clear()
    before = len(selected)
    result = []
    for (value, typ), row in sorted(selected.items()):
        if value in blocked:
            continue
        result.append({**row, 'IDENT_UUID': str(uuid.uuid5(uuid.NAMESPACE_URL,
                      json.dumps([snap['command']['tree_guid'], value, typ])))})
    return result, dict(excluded_imei=len(excluded_imei), blocked_final=before-len(result),
                       selected_by_type=dict(Counter(str(r['TYPE']) for r in result)))


def route_batches(selected, locations, command, batch_size):
    if batch_size < 1:
        raise ValueError('Batch size must be positive')
    groups = defaultdict(dict)
    for row in selected:
        routes = [loc for loc in locations if int(loc['IDENTIFICATOR_TYPE']) == row['TYPE']]
        if not routes:
            raise ValueError(f"No SMS source for type {row['TYPE']}")
        for loc in routes:
            key = (loc['SERVER'], loc['INSTANCE'], loc['DATABASE'], row['TYPE'])
            if not key[0] or not key[2]:
                raise ValueError('Incomplete source catalog')
            groups[key][row['IDENT_UUID']] = dict(ident=row['IDENTIFICATOR'], type=row['TYPE'], uuid=row['IDENT_UUID'])
    batches = []
    for (server, instance, database, typ), entries in sorted(groups.items(), key=lambda x: repr(x[0])):
        idents = normalize_ident_batch(list(entries.values()), typ)
        for offset in range(0, len(idents), batch_size):
            batch = dict(command=command,
                         db_config=dict(server=server, instance=instance, database=database, type=typ,
                                        tree_guid=command['tree_guid'], stat_type='SMS'),
                         ident_batch=idents[offset:offset+batch_size])
            batch['batch_id'] = digest(batch)
            batches.append(batch)
    return batches


def plan(link_ref):
    link_manifest = storage.get_json(link_ref)
    snap = storage.get_json(link_manifest['snapshot'])
    command = snap['command']
    control.assert_owner(command['tree_guid'], command['owner'])
    selected, stats = select_inputs(link_manifest, snap)
    batches = route_batches(selected, sources.catalog() if selected else [], command,
                            positive_env('COMMANDS_IDENT_BATCH_SIZE', 50))
    # Proactive gate before task mapping: never silently truncate an oversized plan.
    if len(batches) > positive_env('COMMANDS_MAX_BATCHES', 1000):
        raise ValueError('Plan exceeds COMMANDS_MAX_BATCHES; increase batch size or mapping limit')
    attempt = uuid.uuid4().hex
    refs = [storage.put_json(f"{command['root']}/plans/{attempt}/{b['batch_id']}.json", b) for b in batches]
    stats.update(main=len(snap['main']), clean_main=len(snap['clean']), first_links=link_manifest['counts'][0],
                 second_links=link_manifest['counts'][1], link_queries=link_manifest['queries'], planned_batches=len(refs))
    result = dict(command=command, snapshot=link_manifest['snapshot'], selected=selected,
                  batches=refs, stats=stats)
    metrics('plan', **stats)
    return storage.put_json(f"{command['root']}/plans/{attempt}/manifest.json", result)


def batch_refs(plan_ref):
    return storage.get_json(plan_ref)['batches']


def extract(batch_ref):
    batch = storage.get_json(batch_ref)
    command = batch['command']
    control.assert_owner(command['tree_guid'], command['owner'])
    started = time.monotonic()
    attempt = uuid.uuid4().hex
    base = f"{command['root']}/batches/{batch['batch_id']}/{attempt}"
    chunks, total = [], 0
    columns = SMS_COLUMNS + ['TREE_GUID','IDENT_UUID','IDENT_TYPE','MATCHED_IDENTIFICATOR']
    schema = pa.schema([(c, pa.string()) for c in columns])
    with tempfile.TemporaryDirectory() as tmp:
        def sink(rows):
            nonlocal total
            # Explicit string schema prevents all-null/numeric-looking chunks changing types.
            clean = [{c: None if r.get(c) is None else str(r[c]) for c in columns} for r in rows]
            table = pa.Table.from_pylist(clean, schema=schema)
            local = Path(tmp) / 'chunk.parquet'
            pq.write_table(table, local, compression='snappy')
            ref = storage.upload(local, f'{base}/{len(chunks):08}.parquet')
            chunks.append({**ref, 'rows': len(rows)})
            total += len(rows)
        count = get_fuzzy_sms_data(batch['db_config'], batch['ident_batch'], on_chunk=sink,
                                  fetch_size=positive_env('COMMANDS_SMS_FETCH_ROWS', 1000))
    if count != total:
        raise ValueError('Extracted row count mismatch')
    control.assert_owner(command['tree_guid'], command['owner'])
    result = dict(batch_ref=batch_ref, batch_id=batch['batch_id'], command=command, chunks=chunks,
                  rows=total, seconds=round(time.monotonic()-started, 3), source=digest(batch['db_config']))
    metrics('extract', rows=total, chunks=len(chunks), seconds=result['seconds'], source=result['source'])
    # Even an empty SQL result has an explicit successful manifest.
    return storage.put_json(f'{base}/manifest.json', result)


def validate_outputs(planned, output_refs):
    expected = {r['sha256']: r for r in planned}
    if len(expected) != len(planned):
        raise ValueError('Duplicate planned batch')
    outputs, seen = [], set()
    for ref in (() if output_refs is None else output_refs):
        if not ref:
            raise ValueError('Missing batch result; empty results must have manifests')
        output = storage.get_json(ref)
        source = output['batch_ref']
        key = source['sha256']
        if key not in expected or source != expected[key] or key in seen:
            raise ValueError('Foreign or duplicate batch result')
        seen.add(key)
        if sum(c['rows'] for c in output['chunks']) != output['rows']:
            raise ValueError('Chunk total mismatch')
        if output['rows'] < 0 or any(c['rows'] <= 0 for c in output['chunks']):
            raise ValueError('Invalid row count')
        batch = storage.get_json(source)
        if output['command'] != batch['command'] or output['batch_id'] != batch['batch_id']:
            raise ValueError('Batch identity mismatch')
        outputs.append((batch, output))
    if seen != set(expected):
        raise ValueError('Not all planned batches completed')
    return sorted(outputs, key=lambda item: item[0]['batch_id'])


RRR = ('ABS','APP','ASMS','ATLF','AWF','BIL','BLC','DBK','EML','GEO','IM','LNK','LOC','MSRN','SMS','TLF','VOIP')


def build_exports(tmp, plan_data, outputs):
    command, counts, paths = plan_data['command'], Counter(), {}
    for batch, output in outputs:
        expected = {r['uuid']: r for r in batch['ident_batch']}
        for chunk in output['chunks']:
            storage.verify(chunk)
            chunk_count = 0
            with storage.open_file(chunk['path']) as src:
                for record_batch in pq.ParquetFile(src).iter_batches(batch_size=1000):
                    by_uid = defaultdict(list)
                    for row in record_batch.to_pylist():
                        uid = row['IDENT_UUID']
                        match = expected.get(uid)
                        if (match is None or row['TREE_GUID'] != command['tree_guid'] or
                            int(row['IDENT_TYPE']) != match['type'] or row['MATCHED_IDENTIFICATOR'] != match['ident']):
                            raise ValueError('Foreign row in Parquet')
                        by_uid[uid].append(row)
                    for uid, rows in by_uid.items():
                        ident = expected[uid]
                        if uid not in paths:
                            # UUID filenames on disk avoid filesystem NAME_MAX for long identifiers.
                            local = Path(tmp) / f'{uid}.SMS'
                            with local.open('w', encoding='utf-8', newline='') as f:
                                csv.writer(f, delimiter='\t').writerow(SMS_COLUMNS)
                            paths[uid] = local
                        with paths[uid].open('a', encoding='utf-8', newline='') as f:
                            writer = csv.writer(f, delimiter='\t')
                            writer.writerows([[row.get(c) for c in SMS_COLUMNS] for row in rows])
                        counts[(ident['ident'], ident['type'])] += len(rows)
                        chunk_count += len(rows)
            if chunk_count != chunk['rows']:
                raise ValueError('Parquet row count mismatch')
    if sum(counts.values()) != sum(o['rows'] for _, o in outputs):
        raise ValueError('Export row count mismatch')
    snap = storage.get_json(plan_data['snapshot'])
    receipt_keys = {(r['IDENTIFICATOR'], int(r['TYPE'])) for r in snap['main']}
    receipt_keys.update((r['IDENTIFICATOR'], r['TYPE']) for r in plan_data['selected'])
    receipt = Path(tmp) / 'receipt.KVT'
    with receipt.open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(('Point','ID','ID_Type','Service','RRR','Count'))
        for value, typ in sorted(receipt_keys):
            for stat in RRR:
                writer.writerow((14,value,ident_name(typ),'UNK',stat,counts[(value,typ)] if stat=='SMS' else 0))
    files = []
    for row in plan_data['selected']:
        uid = row['IDENT_UUID']
        if uid in paths:
            name = f"{command['kom_prefix']}_{ident_name(row['TYPE'])}_UNK_{safe_component(row['IDENTIFICATOR'])}.SMS"
            files.append((paths[uid], name, counts[(row['IDENTIFICATOR'],row['TYPE'])]))
    if len(files) != len(paths):
        raise ValueError('Export contains an unplanned identifier')
    files.append((receipt, f"{command['kom_prefix']}.KVT", len(receipt_keys)*len(RRR)))
    return files, sum(counts.values())


def publish(plan_ref, output_refs):
    data = storage.get_json(plan_ref)
    command = data['command']
    state = control.current(command['tree_guid'])
    if state and state['owner'] == command['owner'] and state['state'] == 'SUCCEEDED':
        # Retry after COMMIT succeeded but the worker lost its response.
        with storage.open_file(state['manifest']) as f:
            sha, size = storage.digest_stream(f)
        if sha != state['sha256']:
            raise ValueError('Committed manifest was modified')
        return dict(path=state['manifest'], sha256=sha, bytes=size)
    control.assert_owner(command['tree_guid'], command['owner'])
    outputs = validate_outputs(data['batches'], output_refs)
    attempt = uuid.uuid4().hex
    base = f"{command['root']}/exports/{attempt}"
    with tempfile.TemporaryDirectory() as tmp:
        files, rows = build_exports(tmp, data, outputs)
        archive = Path(tmp) / 'result.zip'
        if len({name for _, name, _ in files}) != len(files):
            raise ValueError('Duplicate archive member names')
        artifacts = []
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            for local, name, count in files:
                z.write(local, name)
                artifacts.append({**storage.upload(local, f'{base}/{name}'), 'rows': count})
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise ValueError('ZIP CRC validation failed')
        archive_ref = storage.upload(archive, f'{base}/result.zip')
    by_source = defaultdict(lambda: dict(rows=0, seconds=0, batches=0))
    for _, out in outputs:
        stat = by_source[out['source']]
        stat['rows'] += out['rows']; stat['seconds'] += out['seconds']; stat['batches'] += 1
    manifest = dict(command=command, plan=plan_ref, files=artifacts, archive=archive_ref,
                    stats={**data['stats'], 'completed_batches':len(outputs),'sms_rows':rows,
                           'sources':dict(by_source)})
    ref = storage.put_json(f'{base}/manifest.json', manifest)
    # The committed DB pointer is the publication boundary. No mutable latest.json.
    control.complete(command['tree_guid'], command['owner'], ref['path'], ref['sha256'])
    metrics('published', completed_batches=len(outputs), sms_rows=rows)
    return ref
