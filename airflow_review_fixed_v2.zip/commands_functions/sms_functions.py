"""SMS extraction and export. Airflow 3, MSSQL/pymssql and S3/SeaweedFS."""
import os
import uuid
import logging
from contextlib import suppress
from urllib.parse import quote
import pandas as pd
import sqlalchemy as sa

logger = logging.getLogger(__name__)

S3_BASE_BUCKET = os.environ.get('COMMANDS_S3_BUCKET', 's3://airflow-commands').rstrip('/')
SMS_COLUMNS = ['POINT', 'PID', 'LID', 'DATE_TIME', 'OPC', 'DPC', 'NI',
    'PHONE_A', 'PHONE_A_TN', 'PHONE_A_NP', 'IMSI_A', 'IMEI_A',
    'CALLINGPA_A_FROM', 'CALLEDPA_A_FROM', 'SMSC', 'CALLINGPA_A_TO',
    'CALLEDPA_B_TO', 'PHONE_B', 'PHONE_B_TN', 'PHONE_B_NP', 'IMSI_B',
    'IMEI_B', 'TP_PID', 'TP_DCS', 'MESSAGE_ID', 'MESSAGE_PARTS',
    'MESSAGE_PART_NUMBER', 'TEXT', 'HEX_SMS']


def safe_component(value):
    value = str(value)
    if not value or value in ('.', '..'):
        raise ValueError('Empty or invalid filename component')
    return quote(value, safe='-_ .').replace(' ', '%20')


def ident_name(value):
    names = {2: 'PHONE', 19: 'IMSI', 20: 'IMEI'}
    # Email type ID was not supplied; do not silently mislabel unknown IDs.
    extra = os.environ.get('COMMANDS_EMAIL_IDENT_TYPE')
    if extra:
        names[int(extra)] = 'EMAIL'
    try:
        return names[int(value)]
    except (KeyError, ValueError, TypeError) as exc:
        raise ValueError(f'Unknown identifier type: {value}') from exc


def get_storage_options():
    from airflow.sdk import BaseHook
    conn = BaseHook.get_connection(os.environ.get('COMMANDS_S3_CONN_ID', 'commands_s3'))
    extra = conn.extra_dejson
    options = {}
    if conn.login:
        options['key'] = conn.login
    if conn.password:
        options['secret'] = conn.password
    if extra.get('aws_session_token'):
        options['token'] = extra['aws_session_token']
    endpoint = extra.get('endpoint_url')
    if endpoint:
        options['client_kwargs'] = {'endpoint_url': endpoint}
    return options


def select_procedure_identifiers(linked_rows: list[dict], main_identifiers: list[dict]) -> list[dict]:
    """Select unique link endpoints; IMEI is allowed only in the main list.

    Bare main rows retained by get_result_link are not link evidence.
    Membership is scoped to this command and matches both type and value.
    """
    def key(value, typ):
        if value is None or pd.isna(value) or not str(value).strip():
            return None
        if typ is None or pd.isna(typ):
            return None
        return (str(value).strip(), int(typ))

    main_imei = set()
    for row in main_identifiers:
        pair = key(row.get('IDENTIFICATOR'), row.get('TYPE'))
        if pair is not None and pair[1] == 20:
            main_imei.add(pair)

    selected = set()
    for row in linked_rows:
        if not all(col in row for col in ('Idn1', 't1', 'Idn2', 't2')):
            continue
        for value_col, type_col in (('Idn1', 't1'), ('Idn2', 't2')):
            pair = key(row[value_col], row[type_col])
            if pair is not None and (pair[1] in (2, 19) or pair in main_imei):
                selected.add(pair)
    return [{'IDENTIFICATOR': value, 'TYPE': typ}
            for value, typ in sorted(selected, key=lambda pair: (pair[1], pair[0]))]


def normalize_ident_batch(ident_batch: list[dict], default_type=None) -> list[dict]:
    """Validate and deduplicate before loading SQL; one UUID per (value, type)."""
    by_key, by_uuid = {}, {}
    for entry in ident_batch:
        value = entry.get('ident')
        if not isinstance(value, str) or not value.strip():
            raise ValueError('Identifier must be a nonempty string (preserves leading zeros)')
        value = value.strip()
        if len(value.encode('utf-16-le')) // 2 > 255:
            raise ValueError('Identifier exceeds NVARCHAR(255)')
        typ = int(entry.get('type', default_type))
        if typ not in (2, 19, 20):
            raise ValueError(f'Unsupported SMS identifier type: {typ}')
        if default_type is not None and typ != int(default_type):
            raise ValueError('Mixed types in a homogeneous DAG batch')
        uid = str(uuid.UUID(str(entry['uuid'])))
        key = (value, typ)
        if key in by_key and by_key[key]['uuid'] != uid:
            raise ValueError('One identifier/type has multiple UUIDs')
        if uid in by_uuid and by_uuid[uid] != key:
            raise ValueError('UUID belongs to more than one identifier/type')
        by_key[key] = {'ident': value, 'type': typ, 'uuid': uid}
        by_uuid[uid] = key
    return sorted(by_key.values(), key=lambda row: (row['type'], row['ident'], row['uuid']))


def create_sms_engine(db_parametrs: dict):
    from airflow.sdk import BaseHook
    for key in ('server', 'database'):
        if not db_parametrs.get(key):
            raise ValueError(f'Missing SMS parameter: {key}')
    credentials = BaseHook.get_connection(db_parametrs.get('conn_id') or
        os.environ.get('COMMANDS_MSSQL_CONN_ID', 'commands_mssql'))
    server = str(db_parametrs['server']).strip()
    instance = db_parametrs.get('instance')
    if (instance is not None and not pd.isna(instance) and str(instance).strip()
            and str(instance).upper() != 'MSSQLSERVER'):
        if '\\' not in server:
            server += '\\' + str(instance).strip()
    # Named instances use driver resolution; a configured explicit port takes precedence.
    port = db_parametrs.get('port') or credentials.port
    url = sa.engine.URL.create('mssql+pymssql', username=credentials.login,
        password=credentials.password, host=server,
        port=int(port) if port else (None if '\\' in server else 1433),
        database=str(db_parametrs['database']))
    # A dedicated physical session per batch: no surviving #idents in a pool.
    return sa.create_engine(url, poolclass=sa.pool.NullPool, connect_args={
        'timeout': int(os.environ.get('COMMANDS_SMS_QUERY_TIMEOUT', '300')),
        'login_timeout': 15})


def read_sms_batch_result(cursor, ident_batch: list[dict], tree_guid: str, on_chunk=None, fetch_size=1000):
    if fetch_size < 1:
        raise ValueError('fetch_size must be positive')
    total = 0
    expected = {row['uuid']: row for row in ident_batch}
    required = (set(SMS_COLUMNS) - {'CALLEDPA_A_FROM', 'CALLEDPA_B_TO'}) | {
        'TREE_GUID', 'IDENT_UUID', 'IDENT_TYPE', 'MATCHED_IDENTIFICATOR'}
    records, found_result = [], False
    while True:
        if cursor.description is not None:
            if found_result:
                raise ValueError('SMS procedure returned more than one tabular result set')
            found_result = True
            columns = [str(col[0]).upper() for col in cursor.description]
            if len(columns) != len(set(columns)) or not required.issubset(columns):
                raise ValueError(f'Unexpected SMS result schema; missing {sorted(required - set(columns))}')
            while True:
                chunk = cursor.fetchmany(fetch_size)
                if not chunk:
                    break
                validated = []
                for values in chunk:
                    row = dict(zip(columns, values))
                    uid = str(uuid.UUID(str(row['IDENT_UUID'])))
                    tree = str(uuid.UUID(str(row['TREE_GUID'])))
                    match = expected.get(uid)
                    if (match is None or tree != tree_guid or
                            int(row['IDENT_TYPE']) != match['type'] or
                            str(row['MATCHED_IDENTIFICATOR']) != match['ident']):
                        raise ValueError('SMS row does not belong to the requested identifier/type/tree')
                    row['IDENT_UUID'], row['TREE_GUID'] = uid, tree
                    if row.get('DATE_TIME') is not None:
                        row['DATE_TIME'] = str(row['DATE_TIME'])
                    validated.append(row)
                total += len(validated)
                if on_chunk is None:
                    records.extend(validated)
                else:
                    on_chunk(validated)
        if not cursor.nextset():
            break
    if not found_result:
        raise ValueError('SMS procedure did not return a tabular result set')
    return records if on_chunk is None else total


def get_fuzzy_sms_data(db_parametrs: dict, ident_batch: list[dict], on_chunk=None, fetch_size=1000):
    """CREATE #idents -> executemany -> one EXEC -> fetch; all on one session.

    Requires sql/GET_STAT_SMS_BATCH.sql to be installed in every source database.
    """
    batch = normalize_ident_batch(ident_batch, db_parametrs.get('type'))
    tree_guid = str(uuid.UUID(str(db_parametrs['tree_guid'])))
    if not batch:
        return [] if on_chunk is None else 0
    engine = create_sms_engine(db_parametrs)
    raw = cursor = None
    try:
        raw = engine.raw_connection()
        cursor = raw.cursor()
        cursor.execute("""SET NOCOUNT ON; SET XACT_ABORT ON;
            CREATE TABLE #idents (
                IDENTIFICATOR NVARCHAR(255) COLLATE DATABASE_DEFAULT NOT NULL,
                IDENT_TYPE INT NOT NULL,
                IDENT_UUID UNIQUEIDENTIFIER NOT NULL,
                PRIMARY KEY (IDENT_TYPE, IDENTIFICATOR),
                UNIQUE (IDENT_UUID)
            );""")
        # DB-API parameter binding, no SQL string interpolation of identifiers.
        cursor.executemany(
            'INSERT INTO #idents (IDENTIFICATOR, IDENT_TYPE, IDENT_UUID) VALUES (%s, %s, %s)',
            [(row['ident'], row['type'], row['uuid']) for row in batch])
        cursor.execute('EXEC [IAR].[GET_STAT_SMS_BATCH] @TREE_GUID=%s', (tree_guid,))
        result = read_sms_batch_result(cursor, batch, tree_guid, on_chunk, fetch_size)
        cursor.execute('DROP TABLE #idents')
        return result
    finally:
        # The procedure is read-only; only session-local staging is written.
        # No commit or shared staging table is required. Preserve primary errors.
        if raw is not None:
            with suppress(Exception):
                raw.rollback()
        if cursor is not None:
            with suppress(Exception):
                cursor.close()
        if raw is not None:
            with suppress(Exception):
                raw.close()
        engine.dispose()


def create_result_sms_file(params: dict):
    if not params.get('final_path'):
        raise ValueError('Missing final_path')
    df = pd.read_parquet(params['final_path'], storage_options=get_storage_options())
    for col in ('CALLEDPA_A_FROM', 'CALLEDPA_B_TO'):
        if col not in df:
            df[col] = ''
    missing = set(SMS_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(f'Missing SMS columns: {sorted(missing)}')
    typ = int(params['ident_type'])
    name = ident_name(typ)
    tree = safe_component(params['tree_guid'])
    prefix = params['kom_prefix']  # encoded once by DAG
    if '/' in prefix or '\\' in prefix or prefix in ('', '.', '..'):
        raise ValueError('Invalid kom_prefix')
    path = f"{S3_BASE_BUCKET}/{tree}/{prefix}/{prefix}_{name}_UNK_{safe_component(params['ident_val'])}.SMS"
    df[SMS_COLUMNS].to_csv(path, storage_options=get_storage_options(), index=False, sep='\t')
    return {'stat_name': 'SMS', 'stat_type': typ, 'tree_guid': params['tree_guid'],
        'csv_path': path, 'kom_prefix': prefix, 'ident_val': str(params['ident_val']), 'df_size': len(df)}
