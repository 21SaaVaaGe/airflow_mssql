"""References include byte length and SHA-256; no object-store listing for correctness."""
import hashlib
import json
import shutil
from pathlib import Path
import fsspec
from .sms_functions import get_storage_options


def fs_for(path):
    return fsspec.core.url_to_fs(path, **(get_storage_options() if path.startswith('s3://') else {}))


def open_file(path, mode='rb'):
    fs, key = fs_for(path)
    if 'w' in mode:
        parent = key.rsplit('/', 1)[0]
        if parent:
            fs.makedirs(parent, exist_ok=True)
    return fs.open(key, mode)


def digest_stream(stream):
    sha, size = hashlib.sha256(), 0
    for data in iter(lambda: stream.read(1024 * 1024), b''):
        sha.update(data)
        size += len(data)
    return sha.hexdigest(), size


def verify(ref):
    with open_file(ref['path']) as f:
        sha, size = digest_stream(f)
    if (sha, size) != (ref['sha256'], ref['bytes']):
        raise ValueError('Artifact checksum or byte count mismatch')


def upload(local, remote):
    with Path(local).open('rb') as src:
        sha, size = digest_stream(src)
        src.seek(0)
        with open_file(remote, 'wb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
    ref = dict(path=remote, sha256=sha, bytes=size)
    verify(ref)
    return ref


def put_json(path, data):
    payload = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    with open_file(path, 'wb') as f:
        f.write(payload)
    ref = dict(path=path, sha256=hashlib.sha256(payload).hexdigest(), bytes=len(payload))
    verify(ref)
    return ref


def get_json(ref):
    with open_file(ref['path']) as f:
        payload = f.read()
    if len(payload) != ref['bytes'] or hashlib.sha256(payload).hexdigest() != ref['sha256']:
        raise ValueError('JSON artifact checksum mismatch')
    return json.loads(payload)
