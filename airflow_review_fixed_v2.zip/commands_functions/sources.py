"""Read-only source queries. Connection ids retain the supplied deployment defaults."""
import os
from contextlib import contextmanager
import pandas as pd
import sqlalchemy as sa


@contextmanager
def source_connection(conn_id):
    from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
    engine = MsSqlHook(mssql_conn_id=conn_id).get_sqlalchemy_engine()
    try:
        with engine.connect() as conn:
            yield conn
    finally:
        engine.dispose()


def read(conn_id, sql, params=None):
    with source_connection(conn_id) as conn:
        return pd.read_sql(sa.text(sql), conn, params=params)


def candidates():
    return read('hp-storage2', "EXEC [SPS_TREE].[GET_EXISTING_TREES] @STATUS=N'SLAVA'").to_dict('records')


def main_identifiers(tree):
    rows = read('hp-storage2', '''SELECT IDENTIFICATOR, TYPE
        FROM [AI_COMMANDS].[ADDITIONAL_DATA].[IDENTIFICATORS] WHERE TREE_GUID=:tree''', {'tree': tree})
    result = []
    for row in rows.to_dict('records'):
        value = row['IDENTIFICATOR']
        if not isinstance(value, str) or not value.strip():
            raise ValueError('Source identifiers must be nonempty strings')
        result.append({'IDENTIFICATOR': value.strip(), 'TYPE': int(row['TYPE'])})
    if not result:
        raise ValueError('Claimed command has no identifiers')
    return result


def blacklist():
    rows = read('hp-storage9', '''SELECT IDENTIFICATOR FROM [SPAMERS].[ADDITIONAL].[BLACK_IDENTIFICATORS]
        UNION SELECT IDENTIFICATOR FROM [SPAMERS].[ADDITIONAL].[SPAMERS_PERMANENT]''')
    return set(rows['IDENTIFICATOR'].dropna().astype(str).str.strip())


def catalog():
    types = read('head2', 'SELECT IDENTIFICATOR_TYPE, INPUT_TYPES_ID FROM [HEAD].[ARM].[REPORT_INPUT_TYPES]')
    locations = read('head2', '''SELECT SERVER, INSTANCE, [DATABASE], STATISTIC_TYPE_NAME, INPUT_TYPES_ID
        FROM [HEAD].[ARM].[REPORT_LOCATION_NEW]
        WHERE STATISTIC_SUBTYPE='INFORMATIONAL' AND AVAILIBLE=1 AND STATISTIC_TYPE_NAME='SMS' ''')
    merged = types.merge(locations, on='INPUT_TYPES_ID')
    merged = merged.astype(object).where(merged.notna(), None)
    return merged.to_dict('records')


def clickhouse_client():
    from airflow.sdk import BaseHook
    from clickhouse_driver import Client
    conn = BaseHook.get_connection(os.environ.get('LINK_CLICKHOUSE_CONN_ID', 'links_clickhouse'))
    extra = conn.extra_dejson
    return Client(host=conn.host, port=conn.port or 9000, user=conn.login or 'default',
                  password=conn.password or '', secure=bool(extra.get('secure', False)),
                  verify=bool(extra.get('verify', True)),
                  send_receive_timeout=int(os.environ.get('COMMANDS_LINK_TIMEOUT', '300')))


LINK_QUERY = '''SELECT e.Idn1, e.t1, e.Idn2, e.t2,
    minMerge(e.StartDate) AS StartDate, maxMerge(e.EndDate) AS EndDate,
    sumMerge(e.Amount) AS Amount
FROM LINK.events_agg AS e
INNER JOIN input_idents AS i ON e.Idn1=i.ident AND e.t1=i.typ
GROUP BY e.Idn1,e.t1,e.Idn2,e.t2'''


def iter_links(client, pairs, batch_size):
    if batch_size < 1:
        raise ValueError('Link batch size must be positive')
    pairs = sorted(set(pairs))
    cols = ('Idn1','t1','Idn2','t2','StartDate','EndDate','Amount')
    for offset in range(0, len(pairs), batch_size):
        data = pairs[offset:offset + batch_size]
        stream = client.execute_iter(LINK_QUERY, external_tables=[{
            'name': 'input_idents', 'structure': [('ident','String'),('typ','Int32')], 'data': data}],
            settings={'max_block_size': 4096})
        for values in stream:
            row = dict(zip(cols, values))
            for col in ('Idn1','Idn2'):
                if not isinstance(row[col], str):
                    raise ValueError('ClickHouse identifier column must be String')
                row[col] = row[col].strip()
            for col in ('t1','t2','Amount'):
                row[col] = int(row[col])
            for col in ('StartDate','EndDate'):
                row[col] = str(row[col])
            yield row
