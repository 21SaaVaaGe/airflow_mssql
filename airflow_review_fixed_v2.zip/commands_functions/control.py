"""Committed control transactions, separate from read-only source connections."""
import hashlib
import os
from contextlib import contextmanager


def run_key(dag_id, run_id):
    return hashlib.sha256((dag_id + '\0' + run_id).encode()).hexdigest()


@contextmanager
def connection():
    from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
    hook = MsSqlHook(mssql_conn_id=os.environ.get('COMMANDS_CONTROL_CONN_ID', 'commands_control'))
    raw = hook.get_conn()
    try:
        yield raw
        raw.commit()
    except BaseException:
        raw.rollback()
        raise
    finally:
        raw.close()


def reserve(tree, owner, prefix):
    with connection() as raw:
        cursor = raw.cursor()
        try:
            cursor.execute('EXEC AIRFLOW_CONTROL.RESERVE @TREE_GUID=%s,@RUN_KEY=%s,@KOM_PREFIX=%s', (tree, owner, prefix))
            return bool(cursor.fetchone()[0])
        finally:
            cursor.close()


def current(tree):
    with connection() as raw:
        cursor = raw.cursor()
        try:
            cursor.execute('SELECT RUN_KEY,STATE,MANIFEST_URL,MANIFEST_SHA256 FROM AIRFLOW_CONTROL.Execution WHERE TREE_GUID=%s', (tree,))
            row = cursor.fetchone()
            return None if row is None else dict(zip(('owner','state','manifest','sha256'), row))
        finally:
            cursor.close()


def assert_owner(tree, owner):
    state = current(tree)
    if not state or state['owner'] != owner or state['state'] != 'RUNNING':
        raise RuntimeError('Command ownership lost or command is not running')


def complete(tree, owner, manifest, sha256):
    with connection() as raw:
        cursor = raw.cursor()
        try:
            cursor.execute('EXEC AIRFLOW_CONTROL.COMPLETE @TREE_GUID=%s,@RUN_KEY=%s,@MANIFEST_URL=%s,@MANIFEST_SHA256=%s',
                           (tree, owner, manifest, sha256))
        finally:
            cursor.close()


def failure_callback(context):
    owner = run_key(context['dag'].dag_id, context['run_id'])
    # Avoid identifiers, driver SQL parameters and message text in ledger errors.
    error_code = type(context.get('exception')).__name__
    task = context.get('task_instance')
    if task is not None:
        error_code = f'{task.task_id}:{error_code}'[:256]
    with connection() as raw:
        cursor = raw.cursor()
        try:
            cursor.execute('EXEC AIRFLOW_CONTROL.FAIL_RUN @RUN_KEY=%s,@ERROR_CODE=%s', (owner, error_code))
        finally:
            cursor.close()


def for_run(owner):
    with connection() as raw:
        cursor = raw.cursor()
        try:
            cursor.execute('SELECT TREE_GUID,KOM_PREFIX,STATE FROM AIRFLOW_CONTROL.Execution WHERE RUN_KEY=%s', (owner,))
            row = cursor.fetchone()
            return None if row is None else dict(tree=str(row[0]), prefix=row[1], state=row[2])
        finally:
            cursor.close()
