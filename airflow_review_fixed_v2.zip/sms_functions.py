"""Compatibility import; deploy the complete commands_functions package."""
from commands_functions.sms_functions import *  # noqa: F403
