"""Production DAG: deploy this file plus the complete commands_functions package."""
import os
from datetime import datetime, timedelta, timezone
from airflow.sdk import dag, task, get_current_context
from commands_functions import pipeline, control


@dag(dag_id='identity_enrichment_report', start_date=datetime(2026,1,1,tzinfo=timezone.utc),
     schedule='*/15 * * * *', catchup=False, max_active_runs=1,
     on_failure_callback=control.failure_callback,
     default_args={'retries': 2, 'retry_delay': timedelta(minutes=1),
                   'execution_timeout': timedelta(hours=2)}, tags=['identity','sms'])
def identity_enrichment_report():
    @task
    def claim_command():
        ctx = get_current_context()
        return pipeline.claim(ctx['dag'].dag_id, ctx['run_id'])

    @task
    def snapshot_inputs(command):
        return pipeline.snapshot(command)

    @task
    def fetch_links(snapshot_ref):
        return pipeline.links(snapshot_ref)

    @task
    def plan_batches(link_ref):
        return pipeline.plan(link_ref)

    @task
    def expand_refs(plan_ref):
        return pipeline.batch_refs(plan_ref)

    @task(pool=os.environ.get('COMMANDS_SMS_POOL', 'commands_sms'),
          max_active_tis_per_dag=8)
    def extract_batch(batch_ref):
        return pipeline.extract(batch_ref)

    @task(trigger_rule='none_failed_min_one_success')
    def publish_result(plan_ref, output_refs):
        return pipeline.publish(plan_ref, output_refs)

    command = claim_command()
    snapshot_ref = snapshot_inputs(command)
    link_ref = fetch_links(snapshot_ref)
    plan_ref = plan_batches(link_ref)
    refs = expand_refs(plan_ref)
    outputs = extract_batch.expand(batch_ref=refs)
    publish_result(plan_ref, outputs)


identity_enrichment_report()
