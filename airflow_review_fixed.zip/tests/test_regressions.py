"""Offline regression tests: execute actual function ASTs; mock external I/O.
These do NOT import/validate a real Airflow DAG or exercise database drivers.
Run: python -m unittest discover -s tests -v
"""
import ast
import copy
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import uuid
import zipfile
from collections import defaultdict
from contextlib import suppress
from urllib.parse import quote
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def load_functions():
    ns = dict(pd=pd, os=os, uuid=uuid, json=json, hashlib=hashlib,
              defaultdict=defaultdict, suppress=suppress, quote=quote, tempfile=tempfile, zipfile=zipfile,
              logger=logging.getLogger('tests'), S3_BASE_BUCKET='s3://bucket', IDENT_BATCH_SIZE=50)
    for path in (ROOT / 'sms_functions.py', ROOT / 'test.py'):
        tree = ast.parse(path.read_text())
        nodes = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name != 'identity_enrichment_report':
                node = copy.deepcopy(node)
                node.decorator_list = []
                nodes.append(node)
        module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), *nodes], type_ignores=[])
        exec(compile(ast.fix_missing_locations(module), str(path), 'exec'), ns)
        if path.name == 'sms_functions.py':
            for node in tree.body:
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SMS_COLUMNS' for t in node.targets):
                    ns['SMS_COLUMNS'] = ast.literal_eval(node.value)
    ns['get_storage_options'] = lambda: {}
    ns['get_current_context'] = lambda: {'run_id': 'manual__test'}
    return ns


class Regressions(unittest.TestCase):
    def setUp(self):
        self.n = load_functions()
        self.files = {}
        self.csv = {}
        files, csv = self.files, self.csv
        def write(df, path, **kw):
            files[path] = df.copy()
        def write_csv(df, path, **kw):
            csv[path] = df.copy()
        self.patches = [patch.object(pd.DataFrame, 'to_parquet', write),
                        patch.object(pd, 'read_parquet', lambda path, **kw: files[path].copy()),
                        patch.object(pd.DataFrame, 'to_csv', write_csv)]
        for p in self.patches:
            p.start()
            self.addCleanup(p.stop)

    def params(self):
        return {'db_config': {'server': 'host', 'database': 'db', 'tree_guid': '00000000-0000-0000-0000-000000000010',
            'type': 2, 'stat_type': 'SMS', 'kom_prefix': 'prefix'},
            'ident_batch': [{'ident': '001', 'uuid': str(uuid.UUID(int=1))},
                            {'ident': '002', 'uuid': str(uuid.UUID(int=2))}]}

    def output(self, path, typ=2):
        return {'tree_guid': '00000000-0000-0000-0000-000000000010', 'kom_prefix': 'prefix', 'stat_type': 'SMS',
                'ident_type': typ, 'staging_path': path,
                'ident_batch': self.params()['ident_batch'][:1]}

    def test_router_calls_once_per_batch_and_stable_path(self):
        calls = []
        def fetch(db, batch):
            calls.append((db.copy(), list(batch)))
            return [{'TEXT': row['ident'], 'IDENT_UUID': row['uuid']} for row in batch]
        self.n['get_fetcher_map'] = lambda: {'SMS': fetch}
        a = self.n['execute_router'](self.params())
        b = self.n['execute_router'](self.params())
        self.assertEqual(len(calls), 2)  # two task attempts, one DB batch each
        self.assertEqual([row['ident'] for row in calls[0][1]], ['001', '002'])
        self.assertEqual(a['staging_path'], b['staging_path'])
        self.assertEqual(self.files[a['staging_path']]['IDENT_UUID'].nunique(), 2)

    def test_router_foreign_uuid_fails(self):
        self.n['get_fetcher_map'] = lambda: {'SMS': lambda db, batch: [{'IDENT_UUID': 'foreign'}]}
        with self.assertRaises(ValueError):
            self.n['execute_router'](self.params())

    def test_router_database_error_propagates(self):
        def fail(db, batch):
            raise ConnectionError('offline')
        self.n['get_fetcher_map'] = lambda: {'SMS': fail}
        with self.assertRaises(ConnectionError):
            self.n['execute_router'](self.params())

    def test_merge_all_servers_and_retry(self):
        uid = self.params()['ident_batch'][0]['uuid']
        for path, text in [('part1', 'a'), ('part2', 'b')]:
            self.files[path] = pd.DataFrame([{'IDENT_UUID': uid, 'TEXT': text}])
        inputs = [self.output('part1'), self.output('part2')]
        for _ in range(2):
            result = self.n['merge_and_save_all_to_s3'](inputs)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0]['df_size'], 2)
            self.assertEqual(self.files[result[0]['final_path']]['TEXT'].tolist(), ['a', 'b'])
        self.assertIn('part1', self.files)

    def test_missing_uuid_never_broadcasts_data(self):
        self.files['part'] = pd.DataFrame([{'TEXT': 'secret'}])
        with self.assertRaises(ValueError):
            self.n['merge_and_save_all_to_s3']([self.output('part')])

    def test_read_failure_is_not_ignored(self):
        with self.assertRaises(KeyError):
            self.n['merge_and_save_all_to_s3']([self.output('missing')])

    def test_ident_types_do_not_overwrite(self):
        self.files['part'] = pd.DataFrame([{'IDENT_UUID': self.params()['ident_batch'][0]['uuid'], 'TEXT': 'a'}])
        self.files['other'] = self.files['part'].copy()
        result = self.n['merge_and_save_all_to_s3']([self.output('part', 2), self.output('other', 19)])
        self.assertEqual(len({r['final_path'] for r in result}), 2)

    def test_blacklist_is_separate_and_normalized(self):
        self.n['get_spamers'] = lambda: pd.DataFrame({'IDENTIFICATOR': [12]})
        self.n['get_black_list'] = lambda: pd.DataFrame({'IDENTIFICATOR': [' 13 ']})
        got = self.n['check_spamers_black_list']([{'id': '12'}, {'id': '13'}, {'id': '001'}], 'id')
        self.assertEqual(got, [{'id': '001'}])

    def test_preserves_numeric_looking_text(self):
        got = self.n['_normalize_for_parquet'](pd.DataFrame({'PHONE': ['001'], 'TEXT': ['0002']}))
        self.assertEqual(got.iloc[0].tolist(), ['001', '0002'])

    def test_link_filter_keeps_distinct_identifiers(self):
        rows = [dict(Idn1='a', t1=2, Idn2='100', t2=2, StartDate='2020', EndDate='2025', Amount=5),
                dict(Idn1='b', t1=2, Idn2='101', t2=2, StartDate='2021', EndDate='2022', Amount=2)]
        self.assertEqual(len(self.n['get_enrichment_linked_data'](rows, '00000000-0000-0000-0000-000000000010')), 2)

    def test_original_identifiers_without_links_survive(self):
        self.n['step_first_get_linked_data'] = lambda *a: []
        self.n['step_second_get_linked_data'] = lambda *a: []
        rows = [{'IDENTIFICATOR': '001', 'TYPE': 2}]
        self.assertEqual(self.n['get_result_link'](rows, '00000000-0000-0000-0000-000000000010'), rows)

    def test_stable_uuids_distinct_per_type(self):
        rows = [{'IDENTIFICATOR': '001', 'TYPE': 2}, {'IDENTIFICATOR': '001', 'TYPE': 19}]
        a = self.n['create_ident_df'](rows, '00000000-0000-0000-0000-000000000010')
        self.assertEqual(a, self.n['create_ident_df'](rows, '00000000-0000-0000-0000-000000000010'))
        self.assertNotEqual(a[0]['IDENT_UUID'], a[1]['IDENT_UUID'])

    def test_empty_results_produce_zero_receipt(self):
        source = {'tree_guid': '00000000-0000-0000-0000-000000000010', 'kom_prefix': 'prefix', 'kvt_base': self.n['create_kvit_default']('001', 2)}
        result = self.n['create_kvit_result']([], source)
        self.assertEqual(result[0]['df_size'], 17)
        df = self.csv[result[0]['csv_path']]
        self.assertTrue((df['Count'] == 0).all())
        self.assertEqual(df.iloc[0]['ID'], '001')

    def test_receipt_separates_types_and_adds_linked_id(self):
        source = {'tree_guid': '00000000-0000-0000-0000-000000000010', 'kom_prefix': 'prefix', 'kvt_base': self.n['create_kvit_default']('001', 2)}
        results = [dict(tree_guid='00000000-0000-0000-0000-000000000010', kom_prefix='prefix', ident_val='001', stat_name='SMS', stat_type=t, df_size=c)
                   for t, c in [(2, 3), (19, 7)]]
        result = self.n['create_kvit_result'](results, source)
        df = self.csv[result[-1]['csv_path']]
        self.assertEqual(dict(zip(df[df.RRR == 'SMS'].ID_Type, df[df.RRR == 'SMS'].Count)), {'PHONE': 3, 'IMSI': 7})
        self.assertEqual(len(results), 2)

    def test_sms_preserves_existing_called_fields(self):
        row = dict.fromkeys(self.n['SMS_COLUMNS'], '')
        row.update(CALLEDPA_A_FROM='existing', CALLEDPA_B_TO='other')
        self.files['source'] = pd.DataFrame([row])
        result = self.n['create_result_sms_file'](dict(final_path='source', tree_guid='00000000-0000-0000-0000-000000000010',
            kom_prefix='prefix', ident_type=2, ident_val='001'))
        df = self.csv[result['csv_path']]
        self.assertEqual(df.iloc[0]['CALLEDPA_A_FROM'], 'existing')

    def test_second_pass_keeps_all_results_and_first_empty_is_ok(self):
        calls = []
        class FakeClient:
            def __init__(self, **kw): pass
            def execute(self, query, params, **kw):
                calls.append(params['idn'])
                columns = [(c, 'String') for c in ('Idn1', 't1', 'Idn2', 't2', 'StartDate', 'EndDate', 'Amount')]
                return ([] if params['idn'] == 'empty' else [(params['idn'], 2, 'target', 2, '2020', '2021', 1)]), columns
            def disconnect(self): calls.append('closed')
        self.n['Client'] = FakeClient
        sdk = types.ModuleType('airflow.sdk')
        sdk.BaseHook = types.SimpleNamespace(get_connection=lambda _: types.SimpleNamespace(host='h', port=9000, login='u', password='p'))
        rows = [dict(Idn2=i, t2=t, IDENT_UUID='u') for i, t in [('empty', 2), ('001', 2), ('002', 2), ('imei', 20)]]
        with patch.dict(sys.modules, {'airflow.sdk': sdk}):
            got = self.n['step_second_get_linked_data'](rows, '00000000-0000-0000-0000-000000000010')
        self.assertEqual([r['Idn1'] for r in got], ['001', '002'])
        self.assertEqual(calls, ['empty', '001', '002', 'closed'])

    def test_zip_download_failure_propagates(self):
        def fail(*a, **kw): raise FileNotFoundError('missing')
        self.n['fsspec'] = types.SimpleNamespace(filesystem=lambda *a, **kw: types.SimpleNamespace(open=fail))
        with self.assertRaises(FileNotFoundError):
            self.n['create_result_zip']([dict(kom_prefix='prefix', tree_guid='00000000-0000-0000-0000-000000000010', csv_path='s3://b/missing')])

    def test_missing_catalog_fails(self):
        self.n['get_report_location_new'] = lambda: pd.DataFrame()
        with self.assertRaises(ValueError):
            self.n['aggregate_ident_types']([dict(INPUT_TYPES_ID=1)])

    def test_expansion_separates_instances(self):
        rows = [dict(SERVER='s', INSTANCE=i, DATABASE='d', TYPE=2, STATISTIC_TYPE_NAME='SMS', IDENTIFICATOR='001', IDENT_UUID=str(uuid.UUID(int=1))) for i in ['a', 'b']]
        params = dict(tree_guid='00000000-0000-0000-0000-000000000010', kom_prefix='p', data=rows)
        result = self.n['prepare_expansion_params'](params)
        self.assertEqual(len(result), 2)
        self.assertEqual(result, self.n['prepare_expansion_params'](params))


if __name__ == '__main__':
    unittest.main()
