"""DB-API contract tests; no live SQL Server is required."""
import os
from pathlib import Path
import types
import unittest
from unittest.mock import patch
import uuid
from test_regressions import load_functions

TREE = str(uuid.UUID(int=16))
UID = str(uuid.UUID(int=1))


class Cursor:
    def __init__(self, result_sets, fail=None):
        self.sets = result_sets
        self.index = 0
        self.calls = []
        self.fail = fail
        self.executing = False
        self.closed = False
    @property
    def description(self):
        cols, _ = self.sets[self.index]
        return None if cols is None else [(c,) for c in cols]
    def execute(self, sql, params=None):
        self.calls.append(('execute', sql, params))
        if self.fail and self.fail in sql:
            raise ConnectionError('injected failure')
        if sql.startswith('EXEC '):
            self.executing = True
    def executemany(self, sql, params):
        self.calls.append(('executemany', sql, params))
        if self.fail == 'insert':
            raise ConnectionError('insert failure')
    def fetchmany(self, size):
        cols, rows = self.sets[self.index]
        chunk, rows[:] = rows[:size], rows[size:]
        return chunk
    def nextset(self):
        self.index += 1
        return self.index < len(self.sets)
    def close(self): self.closed = True


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.n = load_functions()
        self.batch = [{'ident': '001', 'type': 2, 'uuid': UID}]
        self.db = {'server': 'host', 'database': 'db', 'tree_guid': TREE, 'type': 2}
        self.cols = self.n['SMS_COLUMNS'] + ['TREE_GUID', 'IDENT_UUID', 'IDENT_TYPE', 'MATCHED_IDENTIFICATOR']
        self.row = {c: '' for c in self.cols}
        self.row.update(TREE_GUID=TREE, IDENT_UUID=UID, IDENT_TYPE=2, MATCHED_IDENTIFICATOR='001')
    def result(self, row=None):
        return (self.cols, [[(row or self.row)[c] for c in self.cols]])
    def install_engine(self, cursor):
        raw = types.SimpleNamespace(cursor=lambda: cursor, rollback_count=0, close_count=0)
        def rollback(): raw.rollback_count += 1
        def close(): raw.close_count += 1
        raw.rollback, raw.close = rollback, close
        engine = types.SimpleNamespace(disposed=False, connections=0)
        def connect():
            engine.connections += 1
            return raw
        def dispose(): engine.disposed = True
        engine.raw_connection, engine.dispose = connect, dispose
        self.n['create_sms_engine'] = lambda _: engine
        return raw, engine
    def test_create_insert_exec_same_cursor_one_connection(self):
        cur = Cursor([(None, []), self.result()])
        raw, engine = self.install_engine(cur)
        result = self.n['get_fuzzy_sms_data'](self.db, self.batch)
        self.assertEqual(engine.connections, 1)
        self.assertEqual([c[0] for c in cur.calls], ['execute', 'executemany', 'execute', 'execute'])
        self.assertIn('CREATE TABLE #idents', cur.calls[0][1])
        self.assertEqual(cur.calls[1][2], [('001', 2, UID)])
        self.assertEqual(cur.calls[2][2], (TREE,))
        self.assertEqual(result[0]['IDENT_UUID'], UID)
        self.assertTrue(raw.close_count == 1 and raw.rollback_count == 1 and cur.closed and engine.disposed)
    def test_batch_insert_uses_bound_parameters(self):
        batch = [{'ident': "00'; DROP TABLE users;--", 'type': 2, 'uuid': UID}]
        cur = Cursor([(self.cols, [])]); self.install_engine(cur)
        self.n['get_fuzzy_sms_data'](self.db, batch)
        self.assertNotIn(batch[0]['ident'], cur.calls[1][1])
        self.assertEqual(cur.calls[1][2][0][0], batch[0]['ident'])
    def test_insert_failure_closes_session_and_does_not_execute_proc(self):
        cur = Cursor([], fail='insert'); raw, engine = self.install_engine(cur)
        with self.assertRaises(ConnectionError): self.n['get_fuzzy_sms_data'](self.db, self.batch)
        self.assertFalse(any(c[1].startswith('EXEC ') for c in cur.calls))
        self.assertTrue(cur.closed and engine.disposed and raw.close_count == 1)
    def test_procedure_failure_closes_session(self):
        cur = Cursor([], fail='EXEC '); raw, engine = self.install_engine(cur)
        with self.assertRaises(ConnectionError): self.n['get_fuzzy_sms_data'](self.db, self.batch)
        self.assertTrue(cur.closed and engine.disposed and raw.rollback_count == 1)
    def test_empty_result_with_schema_is_valid(self):
        cur = Cursor([(self.cols, [])]); self.install_engine(cur)
        self.assertEqual(self.n['get_fuzzy_sms_data'](self.db, self.batch), [])
    def test_empty_batch_does_not_connect(self):
        self.n['create_sms_engine'] = lambda _: self.fail('must not connect')
        self.assertEqual(self.n['get_fuzzy_sms_data'](self.db, []), [])
    def test_missing_result_is_error(self):
        with self.assertRaises(ValueError):
            self.n['read_sms_batch_result'](Cursor([(None, [])]), self.batch, TREE)
    def test_two_result_sets_are_error(self):
        with self.assertRaises(ValueError):
            self.n['read_sms_batch_result'](Cursor([self.result(), self.result()]), self.batch, TREE)
    def test_wrong_uuid_type_value_or_tree_is_error(self):
        for key, bad in [('IDENT_UUID', str(uuid.UUID(int=999))), ('TREE_GUID', str(uuid.UUID(int=999))),
                         ('IDENT_TYPE', 19), ('MATCHED_IDENTIFICATOR', '002')]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.n['read_sms_batch_result'](Cursor([self.result({**self.row, key: bad})]), self.batch, TREE)
    def test_conflicting_uuid_or_identifier_rejected(self):
        for other in [dict(ident='002', type=2, uuid=UID), dict(ident='001', type=2, uuid=str(uuid.UUID(int=2)))]:
            with self.assertRaises(ValueError): self.n['normalize_ident_batch']([*self.batch, other], 2)
        self.assertEqual(self.n['normalize_ident_batch'](self.batch * 2, 2), self.batch)
    def test_dag_chunks_after_deduplication(self):
        rows = [dict(SERVER='s', INSTANCE=None, DATABASE='d', TYPE=2, STATISTIC_TYPE_NAME='SMS',
                     IDENTIFICATOR=f'{i:03}', IDENT_UUID=str(uuid.UUID(int=i+1))) for i in range(51)]
        args = dict(tree_guid=TREE, kom_prefix='p', data=rows + [rows[0]])
        with patch.dict(os.environ, {'COMMANDS_IDENT_BATCH_SIZE': '50'}):
            parts = self.n['prepare_expansion_params'](args)
        self.assertEqual([len(p['ident_batch']) for p in parts], [50, 1])
        with patch.dict(os.environ, {'COMMANDS_IDENT_BATCH_SIZE': '0'}), self.assertRaises(ValueError):
            self.n['prepare_expansion_params'](args)
    def test_sql_has_six_typed_joins_and_per_identifier_uuid(self):
        sql = (Path(__file__).resolve().parents[1] / 'sql/GET_STAT_SMS_BATCH.sql').read_text()
        for typ, prefix in [(2, 'PHONE'), (19, 'IMSI'), (20, 'IMEI')]:
            for side in ('FROM', 'TO'):
                self.assertIn(f'ON i.IDENT_TYPE = {typ}\n   AND i.IDENTIFICATOR = A.[{prefix}_IDENTIFICATOR_{side}]', sql)
        self.assertEqual(sql.count('INNER JOIN #idents'), 6)
        self.assertNotIn('@IDENT_UUID', sql)
        self.assertNotIn('nolock', sql.lower())
        self.assertNotIn('as NVARCHAR)', sql)


if __name__ == '__main__': unittest.main()
