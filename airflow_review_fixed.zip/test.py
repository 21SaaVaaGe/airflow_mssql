from __future__ import annotations
import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone
import os
import tempfile
import zipfile
import uuid
import fsspec
import sqlalchemy as sa
import socket
import pandas as pd
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from airflow.sdk import task, dag, get_current_context
from airflow.exceptions import AirflowSkipException
from clickhouse_driver import Client
from typing import Dict, List, Any, Callable, Optional
from commands_functions.sms_functions import (
    get_fuzzy_sms_data, create_result_sms_file, get_storage_options, normalize_ident_batch, select_procedure_identifiers,
    S3_BASE_BUCKET, safe_component, ident_name,
)
from contextlib import contextmanager
import json
import hashlib



logger = logging.getLogger(__name__)

DAG_MSSQL_HP_STORAGE2_CONN_ID = 'hp-storage2'
DAG_MSSSQL_HEAD2_CONN_ID = 'head2'
DAG_MSSQL_HP_STORAGE9_CONN_ID = 'hp-storage9'

IDENT_BATCH_SIZE = 50

SQL_GET_FREE_COMMANDS = f" EXEC [SPS_TREE].[GET_EXISTING_TREES] @STATUS = N'SLAVA'"


@contextmanager
def managed_connection(engine, transaction=False):
    try:
        with (engine.begin() if transaction else engine.connect()) as conn:
            yield conn
    finally:
        engine.dispose()


def create_kvit_default(ident_val: str, ident_type: int):
    df = pd.DataFrame([
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"ABS" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"APP" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"ASMS" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"ATLF" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"AWF" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"BIL" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"BLC" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"DBK" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"EML" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"GEO" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"IM" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"LNK" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"LOC" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"MSRN" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"SMS" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"TLF" , "Count": 0},
{"Point": 14, "ID": '', "ID_Type": '', "Service" : "UNK", "RRR":"VOIP" , "Count": 0}])
    stat_name = ident_name(ident_type)
    df['ID'] = ident_val
    df['ID_Type'] = stat_name
    return df.to_dict(orient='records')
    

def validate_config(parametrs: dict):
    db = parametrs['db_config']
    for key in ('tree_guid', 'stat_type', 'database', 'server', 'type', 'kom_prefix'):
        if db.get(key) is None or str(db[key]).strip() == '':
            raise ValueError(f'Missing database parameter: {key}')
    uuid.UUID(str(db['tree_guid']))
    normalize_ident_batch(parametrs['ident_batch'], db['type'])
    if not parametrs.get('ident_batch'):
        raise ValueError('Empty ident_batch')
    for row in parametrs['ident_batch']:
        if row.get('ident') is None or not str(row['ident']).strip():
            raise ValueError('Empty identifier')
        uuid.UUID(str(row['uuid']))


def get_fetcher_map() -> Dict[str, Callable]:
    # This DAG's catalog is explicitly restricted to SMS.
    return {'SMS': get_fuzzy_sms_data}


def create_clickhouse_client(host: str, user: str, password: str) -> Client:
    return Client(host=host, user=user, password=password, send_receive_timeout=60)


def _mssql(conn_id: str):
    from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook

    return MsSqlHook(mssql_conn_id=conn_id)


def get_black_list():
    hook = _mssql(DAG_MSSQL_HP_STORAGE9_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    sql = """
        SELECT IDENTIFICATOR
        FROM [SPAMERS].[ADDITIONAL].[BLACK_IDENTIFICATORS]
          """
    try:
        with managed_connection(engine) as conn:
            df = pd.read_sql(sa.text(sql), conn)
        return df
    except Exception as e:
        logger.error(f"Error fetching black_list data: {e}")
        raise


def get_spamers():
    hook = _mssql(DAG_MSSQL_HP_STORAGE9_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    sql = """
        SELECT[IDENTIFICATOR]
        FROM [SPAMERS].[ADDITIONAL].[SPAMERS_PERMANENT]
          """
    try:
        with managed_connection(engine) as conn:
            df = pd.read_sql(sa.text(sql), conn)
        return df
    except Exception as e:
        logger.error(f"Error fetching spamers data: {e}")
        raise


def get_report_location_new() -> pd.DataFrame:
    hook = MsSqlHook(DAG_MSSSQL_HEAD2_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    sql = """
         SELECT
       [SERVER]
	  ,[INSTANCE]
      ,[DATABASE]
      ,[TARGET_TABLE]
      ,[LEFT_BOUND]
      ,[RIGHT_BOUND]
      ,[AVAILIBLE]
      ,[STATISTIC_TYPE_NAME]
      ,[INPUT_TYPES_ID]
  FROM [HEAD].[ARM].[REPORT_LOCATION_NEW] WHERE [STATISTIC_SUBTYPE] = 'INFORMATIONAL' and AVAILIBLE = 1 and STATISTIC_TYPE_NAME='SMS' """
    try:
        with managed_connection(engine) as conn:
            df = pd.read_sql(sa.text(sql), conn)
            df['RIGHT_BOUND'] = df['RIGHT_BOUND'].astype('str')
            df['LEFT_BOUND'] = df['LEFT_BOUND'].astype('str')
        return df
    except Exception as e:
        logger.error(f"Error fetching report_location data: {e}")
        raise


def _fetch_clickhouse_data(client: Client, query: str, params: dict) -> List[dict]:
    data, columns = client.execute(query, params=params, with_column_types=True)
    df = pd.DataFrame(data, columns=[c[0] for c in columns])
    for col in ('StartDate', 'EndDate'):
        if col in df:
            df[col] = df[col].astype(str)
    return df.to_dict(orient='records')


def step_get_linked_data_unified(identifier_list: list[dict], tree_guid: str, mode: str = 'first') -> list[dict]:
    if mode not in ('first', 'second'):
        raise ValueError('Unknown link mode')
    if not identifier_list:
        return []
    id_col, type_col = ('IDENTIFICATOR', 'TYPE') if mode == 'first' else ('Idn2', 't2')
    query = """SELECT Idn1, t1, Idn2, t2,
        minMerge(StartDate) AS StartDate, maxMerge(EndDate) AS EndDate,
        sumMerge(Amount) AS Amount FROM LINK.events_agg
        WHERE Idn1 = %(idn)s AND t1 = %(type)s
        GROUP BY Idn1, Idn2, t1, t2"""
    # Idn1 is a string (the original query used toInt64OrZero).
    from airflow.sdk import BaseHook
    conn = BaseHook.get_connection(os.environ.get('LINK_CLICKHOUSE_CONN_ID', 'links_clickhouse'))
    client = Client(host=conn.host, port=conn.port or 9000,
                    user=conn.login or 'default', password=conn.password or '',
                    send_receive_timeout=60)
    result, cache = [], {}
    try:
        for source in identifier_list:
            key = (str(source[id_col]).strip(), int(source[type_col]))
            if mode == 'second' and key[1] == 20:
                continue
            if key not in cache:
                cache[key] = _fetch_clickhouse_data(client, query, {'idn': key[0], 'type': key[1]})
            for link in cache[key]:
                row = dict(link)
                for col in ('TREE_GUID', 'REMARK', 'THEME', 'POMETKA', 'IDENT_UUID'):
                    row[col] = source.get(col)
                row['TREE_GUID'] = str(tree_guid)
                row['IDENTIFICATOR'], row['TYPE'] = key
                for col in ('Idn1', 'Idn2'):
                    row[col] = str(row[col]).strip()
                for col in ('t1', 't2'):
                    row[col] = int(row[col])
                result.append(row)
    finally:
        client.disconnect()
    return result


def check_server_accessibility(aggregate_report_location: list[dict]):
    results = {}
    for entry in aggregate_report_location:
        host = str(entry['SERVER']).strip()
        if host in results:
            continue
        try:
            with socket.create_connection((host, int(entry.get('PORT', 1433))), timeout=3):
                results[host] = True
        except OSError:
            results[host] = False
    return results


def save_to_seaweedfs_pandas_way(df: pd.DataFrame, object_key: str):

    s3_path = f"s3://airflow-commands/{object_key}"


    try:
        df.to_parquet(s3_path, storage_options=get_storage_options(), index=False)
        logger.info(f"Successfully saved to {s3_path}")
    except Exception as e:
        logger.error(f"Error saving with Pandas/s3fs: {e}")
        raise


def create_ident_df(linked_df: list[dict], tree_guid: str):
    result = {}
    for row in linked_df:
        pairs = [('Idn1', 't1'), ('Idn2', 't2')] if 'Idn1' in row else [('IDENTIFICATOR', 'TYPE')]
        for id_col, type_col in pairs:
            ident, typ = str(row[id_col]).strip(), int(row[type_col])
            key = (ident, typ)
            result[key] = {'IDENTIFICATOR': ident, 'TYPE': typ, 'TREE_GUID': str(tree_guid),
                'IDENT_UUID': str(uuid.uuid5(uuid.NAMESPACE_URL, json.dumps([str(tree_guid), ident, typ])))}
    return list(result.values())


def claim_free_commands(limit: int = 1) -> list[dict]:
    hook = _mssql(DAG_MSSQL_HP_STORAGE2_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    if limit < 1:
        raise ValueError('limit must be positive')
    sql = SQL_GET_FREE_COMMANDS
    logger.info(
        "Starting claim_free_commands. Procedure: [SPS_TREE].[GET_EXISTING_TREES]")
    with managed_connection(engine) as conn:
        df_free_commands = pd.read_sql(sa.text(sql), conn)
    if df_free_commands.empty:
        logger.warning('There are no free commands')
        raise AirflowSkipException("No free commands found in MSSQL.")
    all_tree_guids = [str(g)
                      for g in df_free_commands['TREE_GUID'].dropna().unique()]
    logger.info(f"There are {len(all_tree_guids)} free commands")
    df_tree_guid = df_free_commands.drop_duplicates('TREE_GUID').head(limit).copy()
    df_tree_guid['TREE_GUID'] = df_tree_guid['TREE_GUID'].astype(str)
    df_tree_guid['DATE_INPUT'] = df_tree_guid['DATE_INPUT'].astype(str)
    result_df = df_tree_guid[['TREE_GUID', 'DATE_INPUT', 'TREE_NAME']]
    return result_df.to_dict(orient='records')


def get_identifiers_treeguid(tree_guids: dict):
    if not tree_guids:
        return []
    tree_guid = tree_guids['TREE_GUID']
    hook = MsSqlHook(mssql_conn_id=DAG_MSSQL_HP_STORAGE2_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    sql = sa.text(f"""
                SELECT [TREE_GUID]
                     , [IDENTIFICATOR]
                     , [TYPE]
                     , [REMARK]
                     , [THEME]
                     , [POMETKA]
                FROM [AI_COMMANDS].[ADDITIONAL_DATA].[IDENTIFICATORS]
                WHERE TREE_GUID = :tree_guid
            """)
    try:
        with managed_connection(engine) as conn:
            df_detail = pd.read_sql(sql, conn, params={'tree_guid': tree_guid})
    except Exception as e:
        logger.error(f"Error while processing {tree_guid}: {e}")
        raise

    if df_detail.empty:
        return []

    for col in df_detail.columns:
        if df_detail[col].dtype == 'object':
            df_detail[col] = df_detail[col].astype(str)
    return df_detail.to_dict(orient='records')


def enrich_identifiers(identifier_list: list[dict]) -> list[dict]:
    if not identifier_list:
        return []
    df_main = pd.DataFrame(identifier_list)
    hook = _mssql(DAG_MSSSQL_HEAD2_CONN_ID)
    engine = hook.get_sqlalchemy_engine()
    sql_lookup = 'SELECT [IDENTIFICATOR_TYPE], [INPUT_TYPES_ID] FROM [HEAD].[ARM].[REPORT_INPUT_TYPES]'
    try:
        with managed_connection(engine) as conn:
            df_lookup = pd.read_sql(sa.text(sql_lookup), conn)
    except Exception as e:
        logger.error(f"Erorr query exectution: {e}")
        raise
    df_main['TYPE'] = df_main['TYPE'].astype(str)
    df_lookup['IDENTIFICATOR_TYPE'] = df_lookup['IDENTIFICATOR_TYPE'].astype(
        str)

    enriched_df = pd.merge(
        df_main,
        df_lookup,
        left_on='TYPE',
        right_on='IDENTIFICATOR_TYPE',
        how='left'
    )
    if 'IDENTIFICATOR_TYPE' in enriched_df.columns:
        enriched_df = enriched_df.drop(columns=['IDENTIFICATOR_TYPE'])

    if enriched_df['INPUT_TYPES_ID'].isna().any():
        raise ValueError('Unknown identifier TYPE in REPORT_INPUT_TYPES')
    enriched_df['INPUT_TYPES_ID'] = enriched_df['INPUT_TYPES_ID'].astype(int)

    return enriched_df.to_dict(orient='records')


def check_spamers_black_list(identifiers_list: list[dict], column: str):
    if not identifiers_list:
        return []
    blocked = set()
    for source in (get_spamers(), get_black_list()):
        if 'IDENTIFICATOR' not in source.columns:
            raise ValueError('Missing IDENTIFICATOR in block list')
        blocked.update(source['IDENTIFICATOR'].dropna().astype(str).str.strip())
    return [dict(row) for row in identifiers_list
            if row.get(column) is not None and str(row[column]).strip() not in blocked]


def step_first_get_linked_data(cleaned_list: list[dict], tree_guid: str):
    return step_get_linked_data_unified(cleaned_list, tree_guid, 'first')


def step_second_get_linked_data(enriched_list: list[dict], tree_guid: str):
    return step_get_linked_data_unified(enriched_list, tree_guid, 'second')


def get_enrichment_linked_data(cleaned_list: list[dict], tree_guid):
    # No documented rule authorizes deleting different identifiers because their
    # time intervals overlap, or because all but their final digit match.
    if not cleaned_list:
        return []
    return pd.DataFrame(cleaned_list).drop_duplicates().to_dict(orient='records')


def get_result_link(cleaned_list: list[dict], tree_guid):
    first = check_spamers_black_list(
        get_enrichment_linked_data(step_first_get_linked_data(cleaned_list, tree_guid), tree_guid), 'Idn2')
    second = check_spamers_black_list(
        get_enrichment_linked_data(step_second_get_linked_data(first, tree_guid), tree_guid), 'Idn2')
    # Retain original identifiers even when only some of them have links.
    return [*cleaned_list, *get_enrichment_linked_data([*first, *second], tree_guid)]


def aggregate_ident_types(enriched_data: list[dict]) -> list[dict]:
    if not enriched_data:
        return []
    df_report_location = pd.DataFrame(get_report_location_new())
    if df_report_location.empty:
        raise ValueError('No available SMS report locations')

    df_idents = pd.DataFrame(enriched_data)

    df_idents['INPUT_TYPES_ID'] = df_idents['INPUT_TYPES_ID'].astype(int)
    df_report_location['INPUT_TYPES_ID'] = df_report_location['INPUT_TYPES_ID'].astype(
        int)

    merged_df = pd.merge(df_idents, df_report_location,
                         on="INPUT_TYPES_ID", how='inner')

    missing_types = set(df_idents['INPUT_TYPES_ID']) - set(df_report_location['INPUT_TYPES_ID'])
    if missing_types:
        raise ValueError(f'No SMS source for input types: {sorted(missing_types)}')

    cols_to_keep = [
        'SERVER', 'INSTANCE', 'DATABASE', 'TYPE',
        'STATISTIC_TYPE_NAME', 'INPUT_TYPES_ID',
        'IDENTIFICATOR', 'TREE_GUID', 'IDENT_UUID'
    ]

    actual_cols = [c for c in cols_to_keep if c in merged_df.columns]
    final_df = merged_df[actual_cols].drop_duplicates().copy()
    final_df = final_df.astype(object).where(final_df.notna(), None)

    return final_df.to_dict(orient='records')


def _normalize_for_parquet(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    # Never infer numeric types for identifiers, telephone numbers or message text.
    for col in result.select_dtypes(include=['object']).columns:
        result[col] = result[col].astype('string')
    return result




@dag(
    dag_id="identity_enrichment_report",
    description="Identity enrichment and SMS report export",
    start_date=datetime(2026, 1, 1, tzinfo=timezone.utc),
    schedule="*/15 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["identity", "sms", "clickhouse", "mssql"],
    doc_md=__doc__,
)
def identity_enrichment_report():
    @task
    def fetch_free_commands() -> dict:
        source = claim_free_commands()
        if not source:
            raise AirflowSkipException('No free commands')
        tree_guids = source[0]
        single_guid = str(uuid.UUID(str(tree_guids['TREE_GUID'])))
        kom_number = tree_guids['TREE_NAME']
        kom_date = pd.Timestamp(tree_guids['DATE_INPUT']).strftime('%Y%m%d')
        kom_prefix = safe_component(f"{kom_number}_{kom_date}_14")
        return {
            "kom_number": kom_number,
            "kom_date": kom_date,
            "kom_prefix": kom_prefix,
            "tree_guid": single_guid,
            "data": tree_guids
        }

    @task
    def fetch_identifier_for_treeguid(input_dict: list):
        single_guid = input_dict["tree_guid"]
        tree_guids = input_dict["data"]
        kom_prefix = input_dict['kom_prefix']
        kvt_base = []
        if not tree_guids:
            raise AirflowSkipException('The list for tree guids is empty!')
        identifiers_list = get_identifiers_treeguid(tree_guids)
        for row in identifiers_list:
            part = create_kvit_default(row['IDENTIFICATOR'],row['TYPE'])
            kvt_base.extend(part)
        if not identifiers_list:
            raise ValueError('Claimed command has no identifiers')
        if not kvt_base:
            raise ValueError('Claimed command has no identifiers')
        return {"kom_prefix": kom_prefix, "tree_guid": single_guid, "data": identifiers_list, 'kvt_base': kvt_base}

    @task
    def spamers_and_black_list(input_dict: list):
        single_guid = input_dict["tree_guid"]
        identifiers_list = input_dict["data"]
        kom_prefix = input_dict['kom_prefix']
        if not identifiers_list:
            raise AirflowSkipException('The list for tree guids is empty!')
        cleaned_list = check_spamers_black_list(
            identifiers_list, 'IDENTIFICATOR')
        logger.info(
            f"Filtered {len(identifiers_list)} records down to {len(cleaned_list)}")
        return {"kom_prefix": kom_prefix, "tree_guid": single_guid, "data": cleaned_list}

    @task
    def get_links_data(input_dict: list):
        single_guid = input_dict["tree_guid"]
        cleaned_list = input_dict["data"]
        kom_prefix = input_dict['kom_prefix']
        for item in cleaned_list:
            item['IDENT_UUID'] = str(uuid.uuid5(uuid.NAMESPACE_URL, json.dumps([single_guid, str(item['IDENTIFICATOR']), int(item['TYPE'])])))
        linked_list = get_result_link(cleaned_list, single_guid)

        return {"kom_prefix": kom_prefix, "tree_guid": single_guid, "data": linked_list, "main_identifiers": cleaned_list}

    @task
    def enrich_ident_types(input_dict: list):
        single_guid = input_dict["tree_guid"]
        identifiers_list = input_dict["data"]
        kom_prefix = input_dict['kom_prefix']
        selected = select_procedure_identifiers(identifiers_list, input_dict["main_identifiers"])
        new_ident_list = create_ident_df(selected, single_guid)

        enriched_list = enrich_identifiers(new_ident_list)

        return {"kom_prefix": kom_prefix, "tree_guid": single_guid, "data": enriched_list, "ident_list": new_ident_list}

    @task
    def aggregate_report_location(input_dict: list):
        timestamp = safe_component(get_current_context()['run_id'])
        single_guid = input_dict["tree_guid"]
        ident_list = input_dict['ident_list']
        enriched_list = input_dict["data"]
        kom_prefix = input_dict['kom_prefix']
        object_key = f"{single_guid}/{timestamp}_report_location.parquet"

        aggreagated_list = aggregate_ident_types(enriched_list)
        save_to_seaweedfs_pandas_way(
            pd.DataFrame(aggreagated_list), object_key)

        return {"kom_prefix": kom_prefix, "tree_guid": single_guid, "object_key": object_key, "data": aggreagated_list, 'ident_list': ident_list}

    @task
    def prepare_expansion_params(agg_output: dict):
        tree_guid = agg_output["tree_guid"]
        aggregated_list = agg_output["data"]
        kom_prefix = agg_output['kom_prefix']
        expansion_tasks = []
        batch_size = int(os.environ.get('COMMANDS_IDENT_BATCH_SIZE', IDENT_BATCH_SIZE))
        if batch_size < 1:
            raise ValueError('COMMANDS_IDENT_BATCH_SIZE must be positive')

        if not aggregated_list:
            return expansion_tasks

        groups = defaultdict(list)
        for entry in aggregated_list:
            ident_type = entry.get('TYPE')
            key = (entry.get('SERVER'), entry.get('INSTANCE'), entry.get('DATABASE'),
                   str(entry.get('STATISTIC_TYPE_NAME', '')).upper(), str(ident_type))
            groups[key].append(entry)

        for (server, instance, database, stat_type, ident_type), entries in sorted(groups.items(), key=lambda item: repr(item[0])):
            idents = normalize_ident_batch([
                {'ident': str(e['IDENTIFICATOR']), 'uuid': e['IDENT_UUID'], 'type': int(ident_type)}
                for e in entries], ident_type)
            for offset in range(0, len(idents), batch_size):
                db_config = {
                    'server': server, 'database': database, 'instance': instance,
                    'tree_guid': str(uuid.UUID(str(tree_guid))), 'stat_type': stat_type,
                    'type': int(ident_type), 'kom_prefix': kom_prefix,
                }
                expansion_tasks.append({'db_config': db_config,
                                        'ident_batch': idents[offset:offset + batch_size]})

        return expansion_tasks

    @task(retries=2, retry_delay=timedelta(minutes=1))
    def execute_router(parametrs: dict) -> Optional[dict]:
        validate_config(parametrs)
        db = parametrs['db_config']
        stat_type = str(db['stat_type']).upper()
        handler = get_fetcher_map().get(stat_type)
        if handler is None:
            raise ValueError(f'Unsupported stat_type: {stat_type}')
        batch = normalize_ident_batch(parametrs['ident_batch'], db['type'])
        db = {**db, 'tree_guid': str(uuid.UUID(str(db['tree_guid'])))}
        rows = handler(db, batch)  # Exactly one procedure call for the entire batch.
        if not isinstance(rows, list):
            raise TypeError('Batch fetcher must return a list')
        expected = {row['uuid'] for row in batch}
        for record in rows:
            uid = str(uuid.UUID(str(record.get('IDENT_UUID'))))
            if uid not in expected:
                raise ValueError('Batch fetcher returned a foreign IDENT_UUID')
            record['IDENT_UUID'] = uid
        if not rows:
            return None
        run = safe_component(get_current_context()['run_id'])
        digest = hashlib.sha256(json.dumps({'db_config': db, 'ident_batch': batch}, sort_keys=True).encode()).hexdigest()
        path = f"{S3_BASE_BUCKET}/{safe_component(db['tree_guid'])}/staging/{run}/{digest}.parquet"
        _normalize_for_parquet(pd.DataFrame(rows)).to_parquet(path, storage_options=get_storage_options(), index=False)
        return {'stat_type': stat_type, 'tree_guid': db['tree_guid'], 'staging_path': path,
                'kom_prefix': db['kom_prefix'], 'ident_type': int(db['type']),
                'ident_batch': batch}

    @task(trigger_rule='none_failed')
    def merge_and_save_all_to_s3(execution_outputs: list[dict]):
        groups = defaultdict(list)
        seen_paths = set()
        for output in execution_outputs or []:
            if output is None:
                continue
            path = output['staging_path']
            if path in seen_paths:
                continue
            seen_paths.add(path)
            df = pd.read_parquet(path, storage_options=get_storage_options())
            if 'IDENT_UUID' not in df:
                raise ValueError('Missing IDENT_UUID; cannot safely split batch')
            expected = {str(e['uuid']) for e in output['ident_batch']}
            if df['IDENT_UUID'].isna().any() or not set(df['IDENT_UUID'].astype(str)).issubset(expected):
                raise ValueError('Unknown IDENT_UUID in staging data')
            for entry in {str(e['uuid']): e for e in output['ident_batch']}.values():
                part = df[df['IDENT_UUID'].astype(str) == str(entry['uuid'])]
                if not part.empty:
                    key = (output['tree_guid'], output['kom_prefix'], output['stat_type'],
                           int(output['ident_type']), str(entry['ident']))
                    groups[key].append(part)
        result = []
        for (tree, prefix, stat, typ, ident), parts in groups.items():
            df = _normalize_for_parquet(pd.concat(parts, ignore_index=True))
            # No event primary key is provided: preserve source rows, including exact duplicates.
            path = f"{S3_BASE_BUCKET}/{safe_component(tree)}/{safe_component(prefix)}_{stat}_{typ}_{safe_component(ident)}.parquet"
            df.to_parquet(path, storage_options=get_storage_options(), index=False)
            result.append({'stat_type': stat, 'tree_guid': tree, 'kom_prefix': prefix,
                           'ident_type': typ, 'ident_val': ident, 'final_path': path, 'df_size': len(df)})
        # Retain staging inputs so retry after a partial write can reconstruct all outputs.
        return result

    @task
    def create_result_csv(merged_files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        result = []
        for info in merged_files:
            if info['stat_type'] != 'SMS':
                raise ValueError('Only supplied SMS handler has been reviewed')
            result.append(create_result_sms_file(info))
        return result

    @task
    def create_kvit_result(results: list[dict], source: dict) -> list[dict]:
        tree_guid, kom_prefix = source['tree_guid'], source['kom_prefix']
        base = pd.DataFrame(source['kvt_base']).drop_duplicates(['ID', 'ID_Type', 'RRR'])
        base['ID'] = base['ID'].astype(str)
        base['Count'] = 0
        counts = defaultdict(int)
        for r in results:
            if r['tree_guid'] != tree_guid or r['kom_prefix'] != kom_prefix:
                raise ValueError('Mixed command outputs')
            counts[(str(r['ident_val']), ident_name(r['stat_type']), r['stat_name'])] += int(r['df_size'])
        for (ident, typ, stat), count in counts.items():
            mask = (base['ID'] == ident) & (base['ID_Type'] == typ) & (base['RRR'] == stat)
            if not mask.any():
                extra = pd.DataFrame(create_kvit_default(ident, next(r['stat_type'] for r in results
                    if str(r['ident_val']) == ident and ident_name(r['stat_type']) == typ)))
                base = pd.concat([base, extra], ignore_index=True)
                mask = (base['ID'] == ident) & (base['ID_Type'] == typ) & (base['RRR'] == stat)
            base.loc[mask, 'Count'] = count
        path = f'{S3_BASE_BUCKET}/{safe_component(tree_guid)}/{kom_prefix}/{kom_prefix}.KVT'
        base.to_csv(path, storage_options=get_storage_options(), index=False, sep='\t')
        return [*results, {'stat_name': 'KVT', 'stat_type': 0, 'tree_guid': tree_guid,
                 'kom_prefix': kom_prefix, 'csv_path': path, 'ident_val': '', 'df_size': len(base)}]


    @task
    def create_result_zip(results: list[dict]) -> list[str]:
        if not results:
            logger.info("No results to zip.")
            return []
        
        groups = defaultdict(list)
        for r in results:
            group_key = (r['kom_prefix'],r['tree_guid'])
            groups[group_key].append(r['csv_path'])
        generated_zips = []
        with tempfile.TemporaryDirectory() as tmp_dir:
            for (prefix, tree_guid), s3_files in groups.items():
                zip_filename = f"{prefix}.zip"
                local_zip_path = os.path.join(tmp_dir, zip_filename)

                try:
                    with zipfile.ZipFile(local_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        for s3_url in dict.fromkeys(s3_files):
                            filename = os.path.basename(s3_url)
                            local_file_path = os.path.join(tmp_dir, filename)

                            try:
                                logger.info(
                                    f"Downloading {s3_url} for zipping...")

                                fs = fsspec.filesystem(
                                    's3', **get_storage_options())
                                with fs.open(s3_url, 'rb') as fin:
                                    with open(local_file_path, 'wb') as fout:
                                        fout.write(fin.read())

                                zipf.write(local_file_path, filename)
                            except Exception as e:
                                logger.error(
                                    f"Failed to download {s3_url}: {e}")
                                raise
                    remote_zip_path = f"{S3_BASE_BUCKET}/{tree_guid}/{prefix}/{prefix}.zip"

                    logger.info(f"Uploading zip to {remote_zip_path}")
                    fs = fsspec.filesystem('s3', **get_storage_options())
                    with fs.open(remote_zip_path, 'wb') as fout:
                        with open(local_zip_path, 'rb') as fin:
                            fout.write(fin.read())

                    generated_zips.append(remote_zip_path)

                except Exception as e:
                    logger.error(
                        f"Error creating zip for group {prefix}: {e}")

                    raise

        return generated_zips

    tree_guids = fetch_free_commands()
    identifiers_list = fetch_identifier_for_treeguid(tree_guids)
    cleaned_list = spamers_and_black_list(identifiers_list)
    link_data = get_links_data(cleaned_list)
    enriched_data = enrich_ident_types(link_data)
    aggregated_list = aggregate_report_location(enriched_data)
    expand_data = prepare_expansion_params(aggregated_list)
    raw_results = execute_router.expand(parametrs=expand_data)
    s3_results = merge_and_save_all_to_s3(raw_results)
    result_csv = create_result_csv(s3_results)
    kvit_result = create_kvit_result(result_csv, identifiers_list)
    result_zip = create_result_zip(kvit_result)


identity_enrichment_report()
