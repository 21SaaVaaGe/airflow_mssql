"""
Identity enrichment — один DAG.

flow:
  free commands (proc)
  → seed IDs by tree_guid
  → form list
  → health ClickHouse + MSSQL
  → spam / blacklist → bind → informational
  → parquet (DuckDB) → S3/SeaweedFS или local
  → spam #2 (чтение parquet через DuckDB)
  → parallel extract с серверов
  → отчёт по main_identifier (DuckDB)
"""

from __future__ import annotations

import json
import logging
import re
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import duckdb
import pandas as pd

from airflow.decorators import dag, task
from airflow.exceptions import AirflowSkipException
from airflow.hooks.base import BaseHook
from airflow.utils.trigger_rule import TriggerRule

logger = logging.getLogger(__name__)

S3_CONN_ID = "s3_seaweedfs"
S3_BUCKET = "data-lake"
S3_PREFIX = "identity_enrichment"
MSSQL_COMMAND_CONN = "mssql_commands"
MSSQL_LOOKUP_CONN = "mssql_lookup"
CLAIM_PROC = "dbo.usp_claim_free_commands"
LOCAL_PARQUET_DIR = "/opt/airflow/data/identity_enrichment"

ENDPOINTS = [
    {"engine": "mssql", "conn_id": "mssql_shard_01", "server_id": "mssql_01"},
    {"engine": "mssql", "conn_id": "mssql_shard_02", "server_id": "mssql_02"},
    {"engine": "clickhouse", "conn_id": "clickhouse_01", "server_id": "ch_01"},
    {"engine": "clickhouse", "conn_id": "clickhouse_02", "server_id": "ch_02"},
]

SPAM_RE = (
    re.compile(r"(.)\1{6,}"),
    re.compile(r"^test[_-]?", re.I),
    re.compile(r"spam", re.I),
)

default_args = {
    "owner": "data-eng",
    "retries": 2,
    "retry_delay": timedelta(minutes=3),
    "execution_timeout": timedelta(hours=2),
}


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------

def _cfg() -> dict[str, Any]:
    try:
        from airflow.models import Variable

        return json.loads(Variable.get("identity_enrichment_config", default_var="{}") or "{}")
    except Exception:
        return {}


def _storage_mode() -> str:
    """s3 | local — по умолчанию local (без SeaweedFS)."""
    cfg = _cfg()
    return cfg.get("storage_mode") or ("local" if cfg.get("local_parquet_dir") else "local")


def _object_path(logical_date: str, run_id: str, stage: str) -> str:
    cfg = _cfg()
    safe_run = run_id.replace(":", "_").replace("+", "_")
    rel = f"dt={logical_date}/run={safe_run}/stage={stage}/data.parquet"

    if _storage_mode() == "local":
        root = Path(cfg.get("local_parquet_dir") or LOCAL_PARQUET_DIR)
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        return path.as_posix()

    bucket = cfg.get("s3_bucket", S3_BUCKET)
    prefix = cfg.get("s3_prefix", S3_PREFIX)
    return f"s3://{bucket}/{prefix}/{rel}"


def _sql_str(value: str) -> str:
    return value.replace("'", "''")


# ---------------------------------------------------------------------------
# DuckDB parquet IO
# ---------------------------------------------------------------------------

def _duck() -> duckdb.DuckDBPyConnection:
    con = duckdb.connect()
    if _storage_mode() == "s3":
        cfg = _cfg()
        conn = BaseHook.get_connection(cfg.get("s3_conn_id", S3_CONN_ID))
        extra = conn.extra_dejson or {}
        endpoint = extra.get("endpoint_url") or extra.get("host") or conn.host or ""
        endpoint = endpoint.replace("https://", "").replace("http://", "").rstrip("/")
        use_ssl = extra.get("use_ssl", True)
        if str(use_ssl).lower() in {"false", "0", "no"}:
            use_ssl = False

        con.execute("INSTALL httpfs; LOAD httpfs;")
        con.execute(
            f"""
            CREATE OR REPLACE SECRET seaweed (
                TYPE s3,
                KEY_ID '{_sql_str(conn.login or "")}',
                SECRET '{_sql_str(conn.password or "")}',
                ENDPOINT '{_sql_str(endpoint)}',
                URL_STYLE 'path',
                USE_SSL {'true' if use_ssl else 'false'}
            );
            """
        )
    return con


def _to_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame(
            {
                "command_id": pd.Series(dtype="Int64"),
                "tree_guid": pd.Series(dtype="string"),
                "main_identifier": pd.Series(dtype="string"),
                "identifier_value": pd.Series(dtype="string"),
                "identifier_type": pd.Series(dtype="string"),
                "source_system": pd.Series(dtype="string"),
                "role": pd.Series(dtype="string"),
                "reject_reason": pd.Series(dtype="string"),
                "filter_stage": pd.Series(dtype="string"),
            }
        )
    flat = []
    for r in rows:
        item = {}
        for k, v in r.items():
            item[k] = json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
        flat.append(item)
    return pd.DataFrame(flat)


def write_parquet(rows: list[dict[str, Any]], logical_date: str, run_id: str, stage: str) -> str:
    uri = _object_path(logical_date, run_id, stage)
    pdf = _to_frame(rows)
    con = _duck()
    try:
        con.execute(f"COPY (SELECT * FROM pdf) TO '{_sql_str(uri)}' (FORMAT PARQUET, COMPRESSION ZSTD)")
    finally:
        con.close()
    logger.info("parquet write rows=%s → %s", len(rows), uri)
    return uri


def read_parquet(uri: str, sql: str | None = None) -> list[dict[str, Any]]:
    con = _duck()
    try:
        query = sql or f"SELECT * FROM read_parquet('{_sql_str(uri)}')"
        df = con.execute(query).fetchdf()
    finally:
        con.close()
    if df.empty:
        return []
    records = df.where(pd.notnull(df), None).to_dict(orient="records")
    # JSON-колонки после roundtrip
    for row in records:
        for key, val in list(row.items()):
            if isinstance(val, str) and val[:1] in "[{":
                try:
                    row[key] = json.loads(val)
                except json.JSONDecodeError:
                    pass
    return records


# ---------------------------------------------------------------------------
# DB / business
# ---------------------------------------------------------------------------

def _mssql(conn_id: str):
    from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook

    return MsSqlHook(mssql_conn_id=conn_id)


def claim_free_commands(limit: int = 50) -> list[dict]:
    cfg = _cfg()
    hook = _mssql(cfg.get("mssql_command_conn_id", MSSQL_COMMAND_CONN))
    proc = cfg.get("claim_procedure", CLAIM_PROC)
    sql = f"""
    DECLARE @claimed TABLE (
        command_id BIGINT,
        tree_guid UNIQUEIDENTIFIER,
        main_identifier NVARCHAR(256),
        claimed_at DATETIME2
    );
    INSERT INTO @claimed
    EXEC {proc} @limit = %(limit)s, @status_free = 'free', @status_processing = 'processing';
    SELECT
        CAST(command_id AS BIGINT),
        CAST(tree_guid AS VARCHAR(36)),
        main_identifier,
        CONVERT(VARCHAR(33), claimed_at, 126)
    FROM @claimed;
    """
    return [
        {
            "command_id": r[0],
            "tree_guid": r[1],
            "main_identifier": r[2],
            "claimed_at": r[3],
        }
        for r in hook.get_records(sql, parameters={"limit": limit})
    ]


def fetch_seeds(commands: list[dict]) -> list[dict]:
    if not commands:
        return []
    cfg = _cfg()
    hook = _mssql(cfg.get("mssql_lookup_conn_id", MSSQL_LOOKUP_CONN))
    guids = sorted({c["tree_guid"] for c in commands})
    ph = ", ".join(f"%(g{i})s" for i in range(len(guids)))
    params = {f"g{i}": g for i, g in enumerate(guids)}
    rows = hook.get_records(
        f"""
        SELECT CAST(tree_guid AS VARCHAR(36)), identifier_value, identifier_type, source_system
        FROM dbo.tree_identifiers
        WHERE tree_guid IN ({ph})
        """,
        parameters=params,
    )
    by_tree = {c["tree_guid"]: c for c in commands}
    out = []
    for tree_guid, ident, itype, src in rows:
        parent = by_tree.get(tree_guid, {})
        out.append(
            {
                "command_id": parent.get("command_id"),
                "tree_guid": tree_guid,
                "main_identifier": parent.get("main_identifier"),
                "identifier_value": (ident or "").strip().lower(),
                "identifier_type": itype,
                "source_system": src,
                "role": "seed",
            }
        )
    return out


def form_list(rows: list[dict]) -> list[dict]:
    seen, out = set(), []
    for r in rows:
        v = (r.get("identifier_value") or "").strip().lower()
        if not v:
            continue
        key = (r.get("main_identifier"), r.get("identifier_type"), v)
        if key in seen:
            continue
        seen.add(key)
        out.append({**r, "identifier_value": v})
    return out


def is_spam(value: str) -> bool:
    return any(p.search(value) for p in SPAM_RE)


def load_blacklist() -> set[str]:
    try:
        cfg = _cfg()
        hook = _mssql(cfg.get("mssql_lookup_conn_id", MSSQL_LOOKUP_CONN))
        rows = hook.get_records(
            "SELECT LOWER(identifier_value) FROM dbo.identifier_blacklist WHERE is_active = 1"
        )
        return {r[0] for r in rows if r and r[0]}
    except Exception as exc:
        logger.warning("blacklist unavailable: %s", exc)
        return set()


def apply_filters(rows: list[dict], stage: str) -> dict:
    bl = load_blacklist()
    passed, rejected = [], []
    for r in rows:
        v = (r.get("identifier_value") or "").strip().lower()
        if not v:
            rejected.append({**r, "reject_reason": "empty", "filter_stage": stage})
        elif v in bl:
            rejected.append({**r, "reject_reason": "blacklist", "filter_stage": stage})
        elif is_spam(v):
            rejected.append({**r, "reject_reason": "spam", "filter_stage": stage})
        else:
            passed.append({**r, "identifier_value": v, "filter_stage": stage})
    return {"passed": passed, "rejected": rejected}


def bind_and_expand(passed: list[dict]) -> list[dict]:
    if not passed:
        return []
    cfg = _cfg()
    hook = _mssql(cfg.get("mssql_lookup_conn_id", MSSQL_LOOKUP_CONN))
    values = sorted({r["identifier_value"] for r in passed if r.get("identifier_value")})
    if not values:
        return list(passed)

    ph = ", ".join(f"%(v{i})s" for i in range(len(values)))
    params = {f"v{i}": v for i, v in enumerate(values)}
    bound = list(passed)

    try:
        links = hook.get_records(
            f"""
            SELECT LOWER(src_value), src_type, LOWER(dst_value), dst_type, link_type
            FROM dbo.identifier_links
            WHERE LOWER(src_value) IN ({ph})
            """,
            parameters=params,
        )
        by_src: dict[str, list] = {}
        for src, _st, dst, dt, lt in links:
            by_src.setdefault(src, []).append(
                {"identifier_value": dst, "identifier_type": dt, "link_type": lt, "role": "linked"}
            )
        for r in passed:
            for link in by_src.get(r["identifier_value"], []):
                bound.append(
                    {
                        "command_id": r.get("command_id"),
                        "tree_guid": r.get("tree_guid"),
                        "main_identifier": r.get("main_identifier"),
                        "source_system": r.get("source_system"),
                        **link,
                    }
                )
    except Exception as exc:
        logger.warning("links skip: %s", exc)

    mains = sorted({r["main_identifier"] for r in bound if r.get("main_identifier")})
    if not mains:
        return bound

    mph = ", ".join(f"%(m{i})s" for i in range(len(mains)))
    mparams = {f"m{i}": m for i, m in enumerate(mains)}
    try:
        info = hook.get_records(
            f"""
            SELECT main_identifier, LOWER(identifier_value), identifier_type, source_system
            FROM dbo.identifier_profiles
            WHERE main_identifier IN ({mph})
              AND profile_kind = 'informational'
            """,
            parameters=mparams,
        )
        parent = {}
        for r in bound:
            mid = r.get("main_identifier")
            if mid and mid not in parent:
                parent[mid] = r
        seen = {
            (r.get("main_identifier"), r.get("identifier_type"), r.get("identifier_value"))
            for r in bound
        }
        for mid, ident, itype, src in info:
            key = (mid, itype, ident)
            if key in seen:
                continue
            seen.add(key)
            p = parent.get(mid, {})
            bound.append(
                {
                    "command_id": p.get("command_id"),
                    "tree_guid": p.get("tree_guid"),
                    "main_identifier": mid,
                    "identifier_value": ident,
                    "identifier_type": itype,
                    "source_system": src,
                    "role": "informational",
                }
            )
    except Exception as exc:
        logger.warning("informational skip: %s", exc)
    return bound


def probe_endpoint(ep: dict) -> dict:
    try:
        if ep["engine"] == "mssql":
            row = _mssql(ep["conn_id"]).get_first("SELECT 1")
            ok = bool(row and row[0] == 1)
        else:
            import base64
            import urllib.request

            conn = BaseHook.get_connection(ep["conn_id"])
            url = f"http://{conn.host}:{conn.port or 8123}/?query=SELECT%201"
            req = urllib.request.Request(url)
            if conn.login:
                token = base64.b64encode(f"{conn.login}:{conn.password or ''}".encode()).decode()
                req.add_header("Authorization", f"Basic {token}")
            with urllib.request.urlopen(req, timeout=10) as resp:
                ok = resp.read().decode().strip().startswith("1")
    except Exception as exc:
        logger.warning("health %s failed: %s", ep["server_id"], exc)
        ok = False
    return {**ep, "available": ok}


def extract_on_server(ep: dict, identifiers: list[str]) -> list[dict]:
    if not identifiers:
        return []

    if ep["engine"] == "mssql":
        hook = _mssql(ep["conn_id"])
        out = []
        for i in range(0, len(identifiers), 500):
            batch = identifiers[i : i + 500]
            ph = ", ".join(f"%(v{j})s" for j in range(len(batch)))
            params = {f"v{j}": v for j, v in enumerate(batch)}
            rows = hook.get_records(
                f"""
                SELECT LOWER(identifier_value), identifier_type, related_value, related_type, evidence_json
                FROM dbo.identifier_evidence
                WHERE LOWER(identifier_value) IN ({ph})
                """,
                parameters=params,
            )
            for ident, itype, rel, rtype, ev in rows:
                out.append(
                    {
                        "server_id": ep["server_id"],
                        "engine": "mssql",
                        "identifier_value": ident,
                        "identifier_type": itype,
                        "related_value": rel,
                        "related_type": rtype,
                        "evidence": ev,
                        "role": "server_hit",
                    }
                )
        return out

    import base64
    import urllib.parse
    import urllib.request

    conn = BaseHook.get_connection(ep["conn_id"])
    db = conn.schema or "default"
    out = []

    def esc(v: str) -> str:
        return v.replace("\\", "\\\\").replace("'", "\\'")

    for i in range(0, len(identifiers), 500):
        batch = identifiers[i : i + 500]
        in_list = ", ".join(f"'{esc(v)}'" for v in batch)
        query = f"""
        SELECT lower(identifier_value) AS identifier_value,
               identifier_type,
               related_value,
               related_type,
               toJSONString(evidence) AS evidence
        FROM {db}.identifier_evidence
        WHERE lower(identifier_value) IN ({in_list})
        FORMAT JSONEachRow
        """
        url = f"http://{conn.host}:{conn.port or 8123}/?database={urllib.parse.quote(db)}"
        req = urllib.request.Request(
            url,
            data=urllib.parse.urlencode({"query": query}).encode(),
            method="POST",
        )
        if conn.login:
            token = base64.b64encode(f"{conn.login}:{conn.password or ''}".encode()).decode()
            req.add_header("Authorization", f"Basic {token}")
        with urllib.request.urlopen(req, timeout=60) as resp:
            for line in resp.read().decode().splitlines():
                if not line.strip():
                    continue
                row = json.loads(line)
                out.append(
                    {
                        "server_id": ep["server_id"],
                        "engine": "clickhouse",
                        "identifier_value": row.get("identifier_value"),
                        "identifier_type": row.get("identifier_type"),
                        "related_value": row.get("related_value"),
                        "related_type": row.get("related_type"),
                        "evidence": row.get("evidence"),
                        "role": "server_hit",
                    }
                )
    return out


def build_report(
    commands: list[dict],
    idents: list[dict],
    hits: list[dict],
    rejected: list[dict],
) -> list[dict]:
    by_main: dict[str, list] = defaultdict(list)
    value_to_main: dict[str, set] = defaultdict(set)
    for r in idents:
        mid = r.get("main_identifier")
        if mid:
            by_main[mid].append(r)
            if r.get("identifier_value"):
                value_to_main[str(r["identifier_value"])].add(mid)

    hits_by_main: dict[str, list] = defaultdict(list)
    for h in hits:
        for mid in value_to_main.get(str(h.get("identifier_value") or ""), set()):
            hits_by_main[mid].append(h)

    rej_by_main: dict[str, list] = defaultdict(list)
    for r in rejected:
        mid = r.get("main_identifier")
        if mid:
            rej_by_main[mid].append(r)

    report = []
    for cmd in commands:
        mid = cmd["main_identifier"]
        report.append(
            {
                "command_id": cmd.get("command_id"),
                "tree_guid": cmd.get("tree_guid"),
                "main_identifier": mid,
                "identifiers": by_main.get(mid, []),
                "server_hits": hits_by_main.get(mid, []),
                "rejected": rej_by_main.get(mid, []),
                "identifiers_count": len(by_main.get(mid, [])),
                "server_hit_count": len(hits_by_main.get(mid, [])),
                "rejected_count": len(rej_by_main.get(mid, [])),
            }
        )
    return report


def mark_status(command_ids: list[int], status: str) -> None:
    if not command_ids:
        return
    cfg = _cfg()
    hook = _mssql(cfg.get("mssql_command_conn_id", MSSQL_COMMAND_CONN))
    ids = ", ".join(str(int(i)) for i in command_ids)
    hook.run(
        f"""
        UPDATE dbo.enrichment_commands
        SET status = %(status)s, updated_at = SYSUTCDATETIME()
        WHERE command_id IN ({ids})
        """,
        parameters={"status": status},
    )


# ---------------------------------------------------------------------------
# DAG
# ---------------------------------------------------------------------------

@dag(
    dag_id="identity_enrichment_report",
    description="free→filter→parquet(DuckDB)→parallel extract→отчёт по main_identifier",
    start_date=datetime(2026, 1, 1),
    schedule="*/15 * * * *",
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    tags=["identity", "duckdb", "clickhouse", "mssql"],
    doc_md=__doc__,
)
def identity_enrichment_report():
    @task
    def run_ctx(**context) -> dict:
        return {
            "logical_date": context["data_interval_start"].strftime("%Y-%m-%d"),
            "run_id": context["run_id"],
        }

    @task
    def claim() -> list[dict]:
        commands = claim_free_commands()
        if not commands:
            raise AirflowSkipException("нет команд со status=free")
        return commands

    @task
    def seeds(commands: list[dict]) -> list[dict]:
        formed = form_list(fetch_seeds(commands))
        if not formed:
            raise AirflowSkipException("пустой список seed-идентификаторов")
        return formed

    @task
    def health() -> list[dict]:
        cfg = _cfg()
        endpoints = cfg.get("extract_endpoints") or ENDPOINTS
        alive = [r for r in (probe_endpoint(ep) for ep in endpoints) if r["available"]]
        if not alive:
            raise ValueError("нет доступных ClickHouse/MSSQL")
        return [{k: v for k, v in ep.items() if k != "available"} for ep in alive]

    @task
    def enrich_to_parquet(formed: list[dict], ctx: dict) -> dict:
        """В XCom только URI parquet — данные читаем DuckDB'ом дальше."""
        f1 = apply_filters(formed, "pre_bind")
        expanded = bind_and_expand(f1["passed"])
        mid_uri = write_parquet(expanded, ctx["logical_date"], ctx["run_id"], "intermediate")

        expanded_reread = read_parquet(mid_uri)
        f2 = apply_filters(expanded_reread, "post_expand")

        ready_uri = write_parquet(f2["passed"], ctx["logical_date"], ctx["run_id"], "filtered")
        rejected_uri = write_parquet(
            f1["rejected"] + f2["rejected"],
            ctx["logical_date"],
            ctx["run_id"],
            "rejected",
        )
        return {
            "intermediate_uri": mid_uri,
            "ready_uri": ready_uri,
            "rejected_uri": rejected_uri,
            "passed_count": len(f2["passed"]),
            "rejected_count": len(f1["rejected"]) + len(f2["rejected"]),
        }

    @task
    def id_values(payload: dict) -> list[str]:
        uri = payload["ready_uri"]
        rows = read_parquet(
            uri,
            sql=(
                f"SELECT DISTINCT CAST(identifier_value AS VARCHAR) AS identifier_value "
                f"FROM read_parquet('{_sql_str(uri)}') "
                f"WHERE identifier_value IS NOT NULL"
            ),
        )
        return sorted({str(r["identifier_value"]) for r in rows if r.get("identifier_value")})

    @task
    def extract(endpoint: dict, identifiers: list[str]) -> list[dict]:
        return extract_on_server(endpoint, identifiers)

    @task
    def merge_hits(hits: list[list[dict]], ctx: dict) -> str:
        flat: list[dict] = []
        for chunk in hits or []:
            flat.extend(chunk or [])
        return write_parquet(flat, ctx["logical_date"], ctx["run_id"], "server_hits")

    @task
    def final_report(commands: list[dict], payload: dict, hits_uri: str, ctx: dict) -> dict:
        idents = read_parquet(payload["ready_uri"])
        rejected = read_parquet(payload["rejected_uri"])
        hits = read_parquet(hits_uri)
        report = build_report(commands, idents, hits, rejected)
        uri = write_parquet(report, ctx["logical_date"], ctx["run_id"], "final_report")
        mark_status([c["command_id"] for c in commands], "done")
        return {"uri": uri, "rows": len(report)}

    @task(trigger_rule=TriggerRule.ONE_FAILED)
    def mark_failed(commands: list[dict]) -> None:
        mark_status([c["command_id"] for c in commands], "failed")

    ctx = run_ctx()
    commands = claim()
    formed = seeds(commands)
    alive = health()
    payload = enrich_to_parquet(formed, ctx)
    values = id_values(payload)

    per_server = extract.partial(identifiers=values).expand(endpoint=alive)
    hits_uri = merge_hits(per_server, ctx)
    result = final_report(commands, payload, hits_uri, ctx)
    failed = mark_failed(commands)

    # явный граф: health параллельно с enrich, оба нужны до extract
    formed >> alive
    [alive, values] >> per_server
    result >> failed


identity_enrichment_report()
